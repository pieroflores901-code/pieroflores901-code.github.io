package dao;

import Modelo.Cliente;
import modelo.Nodo;

/**
 * DAO de la cola dinámica de atención.
 * Mantiene referencias al frente y al final para encolar en O(1).
 */
public class ColaAtencion {
    private Nodo frente;
    private Nodo fin;
    private int tamano;

    public ColaAtencion() {
        frente = null;
        fin = null;
        tamano = 0;
    }

    public boolean estaVacia() { return frente == null; }
    public int getTamano() { return tamano; }

    // 1. Encolar / registrar un nuevo ticket.
    public boolean encolar(Cliente cliente) {
        if (cliente == null) return false;
        if (buscarCliente(cliente.getNumeroTicket()) != null) return false;

        Nodo nuevo = new Nodo(cliente);
        if (estaVacia()) {
            frente = nuevo;
        } else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
        tamano++;
        return true;
    }

    // 2. Desencolar / atender al cliente que está al frente.
    public Cliente desencolar() {
        if (estaVacia()) return null;

        Cliente atendido = frente.getCliente();
        frente = frente.getSiguiente();
        tamano--;

        if (frente == null) fin = null;
        return atendido;
    }

    // 3. Peek: consulta el siguiente turno sin modificar la cola.
    public Cliente consultarSiguiente() {
        return estaVacia() ? null : frente.getCliente();
    }

    // 4. Mostrar todos los clientes respetando FIFO.
    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("La cola de espera está vacía.");
            return;
        }

        System.out.println("\n--- COLA DE ESPERA (" + tamano + " cliente(s)) ---");
        Nodo actual = frente;
        int posicion = 1;
        while (actual != null) {
            System.out.println(posicion + ". " + actual.getCliente());
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("-----------------------------------------------");
    }

    // 5. Buscar por número de ticket o DNI sin alterar los nodos.
    public Cliente buscarCliente(String criterio) {
        if (criterio == null || criterio.trim().isEmpty()) return null;

        Nodo actual = frente;
        while (actual != null) {
            Cliente c = actual.getCliente();
            if (c.getNumeroTicket().equalsIgnoreCase(criterio.trim())
                    || c.getDni().equalsIgnoreCase(criterio.trim())) {
                return c;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 6. Cancelar un ticket específico, esté al frente, en medio o al final.
    public boolean eliminarPorTicket(String numeroTicket) {
        if (estaVacia() || numeroTicket == null || numeroTicket.trim().isEmpty()) return false;
        numeroTicket = numeroTicket.trim();

        if (frente.getCliente().getNumeroTicket().equalsIgnoreCase(numeroTicket)) {
            desencolar();
            return true;
        }

        Nodo anterior = frente;
        Nodo actual = frente.getSiguiente();

        while (actual != null
                && !actual.getCliente().getNumeroTicket().equalsIgnoreCase(numeroTicket)) {
            anterior = actual;
            actual = actual.getSiguiente();
        }

        if (actual == null) return false;

        anterior.setSiguiente(actual.getSiguiente());
        if (actual == fin) fin = anterior;
        tamano--;
        return true;
    }
}
