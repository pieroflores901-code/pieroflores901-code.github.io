# Pruebas sugeridas

Selecciona la carpeta `prueba/` desde la aplicación y comprueba:

1. **Resumen**: debe mostrar el total de archivos, directorios y bytes.
2. **Listar archivos**: deben aparecer rutas de documentos, contratos, facturas e informes.
3. **Buscar nombre**: busca `contrato` y verifica que aparezca `contrato_001.txt`.
4. **Buscar extensión**: busca `pdf` y verifica que aparezcan los archivos PDF de ejemplo.
5. **Reporte por tipo**: debe agrupar archivos por extensión.
6. **Estructura**: debe representar la jerarquía usando `├──` y `└──`.
7. **Carpeta vacía**: selecciona una carpeta vacía y verifica que el programa no se cierre.
8. **Permisos restringidos**: si el sistema operativo lo permite, prueba una carpeta sin permiso de lectura y verifica las advertencias.

Los tamaños de los archivos de ejemplo son pequeños y ficticios; el tamaño total exacto depende del contenido incluido en este ZIP.
