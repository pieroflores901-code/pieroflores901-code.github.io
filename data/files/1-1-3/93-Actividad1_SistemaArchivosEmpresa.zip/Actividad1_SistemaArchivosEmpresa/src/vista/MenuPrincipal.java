package vista;

import dao.ArchivoDAO;
import modelo.ArchivoInfo;
import modelo.ResultadoAnalisis;
import servicio.AnalizadorArchivos;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

/** Interfaz gráfica de usuario. Solo coordina entradas y presenta resultados. */
public class MenuPrincipal extends JFrame {
    private final AnalizadorArchivos servicio = new AnalizadorArchivos(new ArchivoDAO());
    private final JTextArea salida = new JTextArea();
    private final JLabel estado = new JLabel("Selecciona una carpeta para comenzar.");
    private ResultadoAnalisis resultado;

    public MenuPrincipal() {
        super("Sistema de Gestión y Análisis de Archivos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 620);
        setLocationRelativeTo(null);
        salida.setEditable(false);
        salida.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 13));

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        agregarBoton(botones, "Seleccionar carpeta", this::seleccionarCarpeta);
        agregarBoton(botones, "Listar archivos", this::listarArchivos);
        agregarBoton(botones, "Resumen", this::mostrarResumen);
        agregarBoton(botones, "Buscar nombre", this::buscarNombre);
        agregarBoton(botones, "Buscar extensión", this::buscarExtension);
        agregarBoton(botones, "Reporte por tipo", this::reporteTipos);
        agregarBoton(botones, "Estructura", this::mostrarEstructura);

        add(botones, BorderLayout.NORTH);
        add(new JScrollPane(salida), BorderLayout.CENTER);
        add(estado, BorderLayout.SOUTH);
    }

    private void agregarBoton(JPanel panel, String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.addActionListener(e -> accion.run());
        panel.add(boton);
    }

    private void seleccionarCarpeta() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Selecciona la carpeta raíz que deseas analizar");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        Path raiz = chooser.getSelectedFile().toPath();
        try {
            resultado = servicio.analizar(raiz);
            salida.setText("Análisis completado.\nCarpeta: " + raiz + "\n\n");
            mostrarResumen();
            if (!resultado.getAdvertencias().isEmpty()) {
                salida.append("\nADVERTENCIAS:\n");
                for (String aviso : resultado.getAdvertencias()) salida.append("- " + aviso + "\n");
            }
            estado.setText("Carpeta analizada: " + raiz);
        } catch (IOException | SecurityException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo analizar",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private boolean comprobarResultado() {
        if (resultado == null) {
            JOptionPane.showMessageDialog(this, "Primero selecciona y analiza una carpeta.",
                    "Análisis requerido", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }
        return true;
    }

    private void listarArchivos() {
        if (!comprobarResultado()) return;
        StringBuilder sb = new StringBuilder("ARCHIVOS Y DIRECTORIOS ENCONTRADOS\n\n");
        for (ArchivoInfo info : resultado.getElementos()) {
            sb.append(info.isDirectorio() ? "[DIR]  " : "[FILE] ")
              .append(info.getRuta());
            if (!info.isDirectorio()) sb.append("  (").append(formatearBytes(info.getTamanoBytes())).append(")");
            sb.append('\n');
        }
        if (resultado.getElementos().isEmpty()) sb.append("La carpeta está vacía o no contiene elementos accesibles.\n");
        salida.setText(sb.toString());
    }

    private void mostrarResumen() {
        if (!comprobarResultado()) return;
        salida.setText("RESUMEN DEL ANÁLISIS\n\n"
                + "Carpeta raíz: " + resultado.getRaiz() + "\n"
                + "Archivos accesibles: " + resultado.contarArchivos() + "\n"
                + "Directorios encontrados: " + resultado.contarDirectorios() + "\n"
                + "Tamaño total: " + resultado.calcularTamanoTotal() + " bytes ("
                + formatearBytes(resultado.calcularTamanoTotal()) + ")\n"
                + "Advertencias: " + resultado.getAdvertencias().size() + "\n");
    }

    private void buscarNombre() {
        if (!comprobarResultado()) return;
        String consulta = JOptionPane.showInputDialog(this, "Escribe el nombre o fragmento:");
        if (consulta == null) return;
        mostrarCoincidencias("BÚSQUEDA POR NOMBRE: " + consulta,
                servicio.buscarPorNombre(resultado, consulta));
    }

    private void buscarExtension() {
        if (!comprobarResultado()) return;
        String consulta = JOptionPane.showInputDialog(this, "Escribe la extensión (ej.: pdf o .pdf):");
        if (consulta == null) return;
        mostrarCoincidencias("BÚSQUEDA POR EXTENSIÓN: " + consulta,
                servicio.buscarPorExtension(resultado, consulta));
    }

    private void mostrarCoincidencias(String titulo, List<ArchivoInfo> lista) {
        StringBuilder sb = new StringBuilder(titulo + "\n\n");
        if (lista.isEmpty()) sb.append("No se encontraron coincidencias.\n");
        for (ArchivoInfo info : lista) sb.append(info.getRuta()).append(" — ")
                .append(formatearBytes(info.getTamanoBytes())).append('\n');
        sb.append("\nTotal de coincidencias: ").append(lista.size());
        salida.setText(sb.toString());
    }

    private void reporteTipos() {
        if (!comprobarResultado()) return;
        StringBuilder sb = new StringBuilder("REPORTE DE ARCHIVOS POR TIPO\n\n");
        Map<String, Long> tipos = resultado.contarPorTipo();
        if (tipos.isEmpty()) sb.append("No hay archivos para clasificar.\n");
        for (Map.Entry<String, Long> entrada : tipos.entrySet()) {
            sb.append(String.format("%-20s %d archivo(s)%n", entrada.getKey(), entrada.getValue()));
        }
        salida.setText(sb.toString());
    }

    private void mostrarEstructura() {
        if (!comprobarResultado()) return;
        salida.setText("ESTRUCTURA JERÁRQUICA\n\n" + servicio.mostrarEstructura(resultado));
    }

    private String formatearBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return new DecimalFormat("0.##").format(kb) + " KB";
        double mb = kb / 1024.0;
        if (mb < 1024) return new DecimalFormat("0.##").format(mb) + " MB";
        return new DecimalFormat("0.##").format(mb / 1024.0) + " GB";
    }
}
