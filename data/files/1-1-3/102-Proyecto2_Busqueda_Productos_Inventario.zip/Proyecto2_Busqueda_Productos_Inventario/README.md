# Proyecto 2: Sistema de búsqueda de productos y análisis de inventario

Aplicación de consola en Java, preparada para abrirse como proyecto en Apache NetBeans.

## Requisitos
- JDK 8 o superior.
- Apache NetBeans (o cualquier IDE Java).

## Cómo ejecutar en NetBeans
1. Descomprima el ZIP.
2. En NetBeans seleccione **File > New Project > Java with Ant > Java Project with Existing Sources** (el nombre puede variar según la versión).
3. Nombre del proyecto: `Proyecto2_Busqueda_Productos_Inventario`.
4. Agregue la carpeta `src` como carpeta de fuentes.
5. Use `inventario.Main` como clase principal y ejecute.

También puede compilar desde una terminal situada en la carpeta del proyecto:
```bash
javac -d out src/inventario/*.java
java -cp out inventario.Main
```

## Funcionalidades
1. Registrar productos (código, descripción, precio y cantidad).
2. Mostrar productos ordenados por código.
3. Buscar por código mediante búsqueda binaria recursiva.
4. Calcular el valor monetario total recursivamente.
5. Calcular las unidades disponibles recursivamente.
6. Identificar productos sin existencias recursivamente.
7. Generar un reporte de bajo inventario indicando el límite.

El programa carga cinco productos de demostración al iniciar. Los datos se mantienen en memoria durante la ejecución; al cerrar la aplicación se reinician.

## Validaciones
- Código y descripción obligatorios.
- Precio y cantidad no pueden ser negativos.
- No se permiten códigos duplicados.
- La búsqueda binaria ordena primero los productos por código.
