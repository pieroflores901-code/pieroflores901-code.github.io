package vista;

import dao.PilaAlumno;
import modelo.Alumno;
import java.util.Scanner;

public class AplicaAlumno {
    private static final Scanner teclado = new Scanner(System.in);

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            if (!teclado.hasNextLine()) throw new IllegalStateException("Fin de entrada.");
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) return texto;
            System.out.println("El texto no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje, int minimo, int maximo) {
        while (true) {
            try {
                int valor = Integer.parseInt(leerTexto(mensaje));
                if (valor >= minimo && valor <= maximo) return valor;
            } catch (NumberFormatException e) { }
            System.out.println("Ingrese un entero entre " + minimo + " y " + maximo + ".");
        }
    }

    private static double leerPromedio() {
        while (true) {
            try {
                double valor = Double.parseDouble(leerTexto("Promedio (0 a 20): ").replace(',', '.'));
                if (Double.isFinite(valor) && valor >= 0 && valor <= 20) return valor;
            } catch (NumberFormatException e) { }
            System.out.println("Ingrese un promedio válido de 0 a 20.");
        }
    }

    public static void main(String[] args) {
        try { menu(); }
        catch (IllegalStateException e) { System.out.println("Entrada finalizada. Sistema cerrado."); }
    }

    private static void menu() {
        int capacidad = leerEntero("Capacidad de la pila: ", 1, Integer.MAX_VALUE);
        PilaAlumno pila = new PilaAlumno(capacidad);
        int opcion;
        do {
            System.out.println("\nGESTIÓN DE ALUMNOS - PILA ESTÁTICA");
            System.out.println("1. Insertar alumno");
            System.out.println("2. Mostrar pila");
            System.out.println("3. Extraer alumno de la cima");
            System.out.println("4. Vaciar pila");
            System.out.println("5. Consultar cima");
            System.out.println("6. Mostrar estado de capacidad");
            System.out.println("7. Buscar alumno por código");
            System.out.println("8. Verificar estado lógico");
            System.out.println("9. Mostrar mejor promedio");
            System.out.println("0. Salir");
            opcion = leerEntero("Seleccione una opción: ", 0, 9);
            switch (opcion) {
                case 1:
                    if (pila.estaLlena()) {
                        System.out.println("Pila llena. No se puede insertar (Overflow)."); break;
                    }
                    Alumno alumno = new Alumno(leerTexto("Código: "), leerTexto("Nombre: "),
                        leerEntero("Edad: ", 1, Integer.MAX_VALUE), leerPromedio());
                    pila.insertarPila(alumno); break;
                case 2: pila.mostrarPila(); break;
                case 3: pila.eliminaDatos(); break;
                case 4: pila.eliminaPila(); break;
                case 5: pila.consultarCima(); break;
                case 6: pila.mostrarEstadoCapacidad(); break;
                case 7: pila.buscarAlumnoPorCodigo(leerTexto("Código a buscar: ")); break;
                case 8: pila.verificarEstadoLogico(); break;
                case 9: pila.mostrarMejorPromedio(); break;
                case 0: System.out.println("Sistema finalizado."); break;
                default: break;
            }
        } while (opcion != 0);
    }
}
