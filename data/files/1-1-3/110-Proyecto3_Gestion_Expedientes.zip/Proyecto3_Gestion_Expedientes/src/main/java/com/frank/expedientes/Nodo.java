package com.frank.expedientes;

/** Nodo del árbol binario de búsqueda. */
class Nodo {
    Expediente expediente;
    Nodo izquierdo, derecho;
    Nodo(Expediente expediente) { this.expediente = expediente; }
}
