package DAO;

import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class DAOAlumno {

    private final ArrayList<Alumno> listaAlumnos;

    public DAOAlumno() {
        listaAlumnos = new ArrayList<>();
    }

    public void agregar(Alumno alumno) {
        listaAlumnos.add(alumno);
    }

    public ArrayList<Alumno> listar() {
        return listaAlumnos;
    }

    public Alumno buscar(int codigo) {
        for (Alumno alumno : listaAlumnos) {
            if (alumno.getCodigo() == codigo) {
                return alumno;
            }
        }
        return null;
    }

    public boolean modificar(int codigo, Alumno alumnoNuevo) {
        for (int i = 0; i < listaAlumnos.size(); i++) {
            if (listaAlumnos.get(i).getCodigo() == codigo) {
                listaAlumnos.set(i, alumnoNuevo);
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(int codigo) {
        for (int i = 0; i < listaAlumnos.size(); i++) {
            if (listaAlumnos.get(i).getCodigo() == codigo) {
                listaAlumnos.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean existeAlumnos() {
        return !listaAlumnos.isEmpty();
    }

    public int cantidadAlumnos() {
        return listaAlumnos.size();
    }

    public ArrayList<Alumno> buscarPorNombre(String nombre) {
        ArrayList<Alumno> encontrados = new ArrayList<>();
        for (Alumno alumno : listaAlumnos) {
            if (alumno.getNombres().toLowerCase().contains(nombre.toLowerCase())) {
                encontrados.add(alumno);
            }
        }
        return encontrados;
    }

    public ArrayList<Alumno> listarPorCarrera(String carrera) {
        ArrayList<Alumno> encontrados = new ArrayList<>();
        for (Alumno alumno : listaAlumnos) {
            if (alumno.getCarrera().equalsIgnoreCase(carrera)) {
                encontrados.add(alumno);
            }
        }
        return encontrados;
    }

    public void ordenarPorApellidos() {
        Collections.sort(listaAlumnos, Comparator.comparing(Alumno::getApellidos, String.CASE_INSENSITIVE_ORDER));
    }

    public void ordenarPorEdad() {
        Collections.sort(listaAlumnos, Comparator.comparingInt(Alumno::getEdad));
    }

    public void invertirLista() {
        Collections.reverse(listaAlumnos);
    }

    public Alumno obtenerPrimero() {
        if (listaAlumnos.isEmpty()) {
            return null;
        }
        return listaAlumnos.get(0);
    }

    public Alumno obtenerUltimo() {
        if (listaAlumnos.isEmpty()) {
            return null;
        }
        return listaAlumnos.get(listaAlumnos.size() - 1);
    }

    public int eliminarPorCarrera(String carrera) {
        int contador = 0;
        for (int i = listaAlumnos.size() - 1; i >= 0; i--) {
            if (listaAlumnos.get(i).getCarrera().equalsIgnoreCase(carrera)) {
                listaAlumnos.remove(i);
                contador++;
            }
        }
        return contador;
    }

    public int contarPorCarrera(String carrera) {
        int contador = 0;
        for (Alumno alumno : listaAlumnos) {
            if (alumno.getCarrera().equalsIgnoreCase(carrera)) {
                contador++;
            }
        }
        return contador;
    }

    public ArrayList<Alumno> mostrarRango(int inicio, int fin) {
        ArrayList<Alumno> rango = new ArrayList<>();
        if (inicio < 1 || fin < inicio || fin > listaAlumnos.size()) {
            return rango;
        }
        for (int i = inicio - 1; i <= fin - 1; i++) {
            rango.add(listaAlumnos.get(i));
        }
        return rango;
    }
}
