package arreglo01;

import java.util.Scanner;

public class Arreglo01 {

    static int[] numerito;
    static int tope = 0;
    static Scanner teclado = new Scanner(System.in);

    public Arreglo01() {
    }

    public void creaArreglo(int valor) {
        numerito = new int[valor];
        tope = 0;
    }

    public void lectura() {
        if (tope < numerito.length) {
            numerito[tope] = getNumero();
            tope++;
        }
    }

    public int getNumero() {
        int valor;
        System.out.print("Ingrese un Numero : ");
        valor = teclado.nextInt();
        return valor;
    }

    public void escritura() {
        System.out.println("\tListado");
        System.out.println("\t-------");

        if (tope > 0) {
            for (int i = 0; i < tope; i++) {
                System.out.print(numerito[i] + "\t");
            }
        } else {
            System.out.println("No existe elementos");
        }
        System.out.println("\n\n");
    }

    public void eliminarElemento(int x) {
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                for (int j = i; j < tope - 1; j++) {
                    numerito[j] = numerito[j + 1];
                }
                tope--;
                break;
            }
        }
    }

    public void modificarElemento(int x, int nuevo) {
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                numerito[i] = nuevo;
                break;
            }
        }
    }

    public void insertarElemento(int x, int y) {
        if (tope < numerito.length && y >= 0 && y <= tope) {
            for (int i = tope; i > y; i--) {
                numerito[i] = numerito[i - 1];
            }
            numerito[y] = x;
            tope++;
        }
    }

    public void sumarElementos() {
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            suma = suma + numerito[i];
        }
        System.out.println("La Suma es : " + suma);
    }

    public void menorMayorPromedio() {
        if (tope > 0) {
            int menor = numerito[0];
            int mayor = numerito[0];
            int suma = 0;

            for (int i = 0; i < tope; i++) {
                if (numerito[i] < menor) {
                    menor = numerito[i];
                }
                if (numerito[i] > mayor) {
                    mayor = numerito[i];
                }
                suma = suma + numerito[i];
            }

            double promedio = (double) suma / tope;
            System.out.println("El menor es : " + menor);
            System.out.println("El mayor es : " + mayor);
            System.out.println("El promedio es : " + promedio);
        }
    }

    public void sumarImpares() {
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] % 2 != 0) {
                suma = suma + numerito[i];
            }
        }
        System.out.println("La Suma de Impares es : " + suma);
    }

    public void primerElementoAlFinal() {
        if (tope > 1) {
            int aux = numerito[0];
            for (int i = 0; i < tope - 1; i++) {
                numerito[i] = numerito[i + 1];
            }
            numerito[tope - 1] = aux;
        }
    }

    public void primerParAlFinal() {
        if (tope > 0) {
            for (int i = 0; i < tope; i++) {
                if (numerito[i] % 2 == 0) {
                    int aux = numerito[i];
                    for (int j = i; j < tope - 1; j++) {
                        numerito[j] = numerito[j + 1];
                    }
                    numerito[tope - 1] = aux;
                    break;
                }
            }
        }
    }
}
