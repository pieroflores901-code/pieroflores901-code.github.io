package DAO;

import Modelo.Curso;
import Modelo.Estudiante;
import Modelo.Matricula;
import java.util.ArrayList;
import java.util.Comparator;

public class SistemaAcademico {
    private final ArrayList<Estudiante> estudiantes = new ArrayList<>();
    private final ArrayList<Curso> cursos = new ArrayList<>();
    private final ArrayList<Matricula> matriculas = new ArrayList<>();

    public boolean registrarEstudiante(Estudiante estudiante) {
        if (buscarEstudiante(estudiante.getCodigo()) != null) {
            return false;
        }
        estudiantes.add(estudiante);
        return true;
    }

    public ArrayList<Estudiante> listarEstudiantes() {
        return new ArrayList<>(estudiantes);
    }

    public Estudiante buscarEstudiante(String codigo) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getCodigo().equalsIgnoreCase(codigo)) {
                return estudiante;
            }
        }
        return null;
    }

    public boolean modificarEstudiante(String codigo, String nombres, String apellidos, String carrera) {
        Estudiante estudiante = buscarEstudiante(codigo);
        if (estudiante == null) {
            return false;
        }
        estudiante.setNombres(nombres);
        estudiante.setApellidos(apellidos);
        estudiante.setCarrera(carrera);
        return true;
    }

    public boolean eliminarEstudiante(String codigo) {
        Estudiante estudiante = buscarEstudiante(codigo);
        if (estudiante == null) {
            return false;
        }
        matriculas.removeIf(matricula -> matricula.getEstudiante().getCodigo().equalsIgnoreCase(codigo));
        estudiantes.remove(estudiante);
        return true;
    }

    public boolean registrarCurso(Curso curso) {
        if (buscarCurso(curso.getCodigo()) != null) {
            return false;
        }
        cursos.add(curso);
        return true;
    }

    public ArrayList<Curso> listarCursos() {
        return new ArrayList<>(cursos);
    }

    public Curso buscarCurso(String codigo) {
        for (Curso curso : cursos) {
            if (curso.getCodigo().equalsIgnoreCase(codigo)) {
                return curso;
            }
        }
        return null;
    }

    public boolean modificarCurso(String codigo, String nombre, int creditos) {
        Curso curso = buscarCurso(codigo);
        if (curso == null) {
            return false;
        }
        curso.setNombre(nombre);
        curso.setCreditos(creditos);
        return true;
    }

    public boolean eliminarCurso(String codigo) {
        Curso curso = buscarCurso(codigo);
        if (curso == null) {
            return false;
        }
        matriculas.removeIf(matricula -> matricula.getCurso().getCodigo().equalsIgnoreCase(codigo));
        cursos.remove(curso);
        return true;
    }

    public int registrarMatricula(String codigoEstudiante, String codigoCurso, double nota) {
        Estudiante estudiante = buscarEstudiante(codigoEstudiante);
        Curso curso = buscarCurso(codigoCurso);
        if (estudiante == null || curso == null) {
            return 0;
        }
        for (Matricula matricula : matriculas) {
            if (matricula.getEstudiante().getCodigo().equalsIgnoreCase(codigoEstudiante)
                    && matricula.getCurso().getCodigo().equalsIgnoreCase(codigoCurso)) {
                return -1;
            }
        }
        String codigo = String.format("M%03d", matriculas.size() + 1);
        matriculas.add(new Matricula(codigo, estudiante, curso, nota));
        return 1;
    }

    public ArrayList<Matricula> listarMatriculas() {
        return new ArrayList<>(matriculas);
    }

    public ArrayList<Matricula> consultarCursosEstudiante(String codigoEstudiante) {
        ArrayList<Matricula> resultado = new ArrayList<>();
        for (Matricula matricula : matriculas) {
            if (matricula.getEstudiante().getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                resultado.add(matricula);
            }
        }
        return resultado;
    }

    public boolean modificarNota(String codigoMatricula, double nota) {
        for (Matricula matricula : matriculas) {
            if (matricula.getCodigo().equalsIgnoreCase(codigoMatricula)) {
                matricula.setNota(nota);
                return true;
            }
        }
        return false;
    }

    public boolean eliminarMatricula(String codigoMatricula) {
        for (int i = 0; i < matriculas.size(); i++) {
            if (matriculas.get(i).getCodigo().equalsIgnoreCase(codigoMatricula)) {
                matriculas.remove(i);
                return true;
            }
        }
        return false;
    }

    public double promedioEstudiante(String codigoEstudiante) {
        double suma = 0;
        int contador = 0;
        for (Matricula matricula : matriculas) {
            if (matricula.getEstudiante().getCodigo().equalsIgnoreCase(codigoEstudiante)) {
                suma += matricula.getNota();
                contador++;
            }
        }
        return contador == 0 ? -1 : suma / contador;
    }

    public ArrayList<Estudiante> rankingAcademico() {
        ArrayList<Estudiante> ranking = new ArrayList<>();
        for (Estudiante estudiante : estudiantes) {
            if (promedioEstudiante(estudiante.getCodigo()) >= 0) {
                ranking.add(estudiante);
            }
        }
        ranking.sort(Comparator.comparingDouble((Estudiante e) -> promedioEstudiante(e.getCodigo())).reversed());
        return ranking;
    }

    public ArrayList<Estudiante> estudiantesPorCarrera(String carrera) {
        ArrayList<Estudiante> resultado = new ArrayList<>();
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getCarrera().equalsIgnoreCase(carrera)) {
                resultado.add(estudiante);
            }
        }
        return resultado;
    }

    public ArrayList<Matricula> estudiantesDesaprobados() {
        ArrayList<Matricula> resultado = new ArrayList<>();
        for (Matricula matricula : matriculas) {
            if (matricula.getNota() < 11) {
                resultado.add(matricula);
            }
        }
        return resultado;
    }

    public Estudiante mejorPromedio() {
        ArrayList<Estudiante> ranking = rankingAcademico();
        return ranking.isEmpty() ? null : ranking.get(0);
    }
}
