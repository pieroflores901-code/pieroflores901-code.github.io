package com.frank.expedientes;

/** Representa un expediente académico. */
public class Expediente {
    private final int codigo;
    private final String nombreEstudiante;
    private final String estado;

    public Expediente(int codigo, String nombreEstudiante, String estado) {
        if (codigo <= 0) throw new IllegalArgumentException("El código debe ser mayor que cero.");
        if (nombreEstudiante == null || nombreEstudiante.trim().isEmpty())
            throw new IllegalArgumentException("Ingrese el nombre del estudiante.");
        if (estado == null || estado.trim().isEmpty())
            throw new IllegalArgumentException("Ingrese el estado del expediente.");
        this.codigo = codigo;
        this.nombreEstudiante = nombreEstudiante.trim();
        this.estado = estado.trim();
    }
    public int getCodigo() { return codigo; }
    public String getNombreEstudiante() { return nombreEstudiante; }
    public String getEstado() { return estado; }
    @Override public String toString() {
        return codigo + " | " + nombreEstudiante + " | " + estado;
    }
}
