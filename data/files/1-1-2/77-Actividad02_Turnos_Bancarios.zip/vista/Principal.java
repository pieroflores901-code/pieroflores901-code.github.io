package vista;

import dao.ColaAtencion;
import Modelo.Cliente;
import java.util.Scanner;

public class Principal {
    private static final Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        ColaAtencion cola = new ColaAtencion();
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1: registrarCliente(cola); break;
                case 2:
                    Cliente atendido = cola.desencolar();
                    if (atendido == null) {
                        System.out.println("[Aviso] No hay clientes pendientes.");
                    } else {
                        System.out.println("[Atención] Cliente llamado a ventanilla:");
                        System.out.println(atendido);
                    }
                    break;
                case 3:
                    Cliente siguiente = cola.consultarSiguiente();
                    System.out.println(siguiente == null
                            ? "No hay un siguiente turno."
                            : "[Siguiente turno] " + siguiente);
                    break;
                case 4: cola.mostrarCola(); break;
                case 5: buscarCliente(cola); break;
                case 6: cancelarTurno(cola); break;
                case 0: System.out.println("Saliendo del sistema..."); break;
                default: System.out.println("[Error] Opción no válida.");
            }
        } while (opcion != 0);

        teclado.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n==============================================");
        System.out.println(" SISTEMA DE GESTIÓN DE TURNOS - BANCO DIGITAL");
        System.out.println("==============================================");
        System.out.println("1. Encolar / Registrar ticket");
        System.out.println("2. Atender / Desencolar cliente");
        System.out.println("3. Consultar siguiente turno");
        System.out.println("4. Mostrar cola de espera completa");
        System.out.println("5. Buscar cliente por ticket o DNI");
        System.out.println("6. Cancelar / Eliminar turno específico");
        System.out.println("0. Salir");
    }

    private static void registrarCliente(ColaAtencion cola) {
        System.out.println("\n--- REGISTRAR CLIENTE ---");
        String ticket = leerTexto("Número de ticket (ej. T-001): ");
        String dni = leerTexto("DNI: ");
        String nombre = leerTexto("Nombre completo: ");
        String tramite = leerTexto("Tipo de trámite: ");
        int prioridad;
        do {
            prioridad = leerEntero("Prioridad (1 = Normal, 2 = Preferencial): ");
            if (prioridad != 1 && prioridad != 2)
                System.out.println("Ingrese 1 o 2.");
        } while (prioridad != 1 && prioridad != 2);
        String hora = leerTexto("Hora de llegada: ");

        Cliente cliente = new Cliente(ticket, dni, nombre, tramite, prioridad, hora);
        if (cola.encolar(cliente)) {
            System.out.println("[Éxito] Ticket registrado. Clientes en espera: " + cola.getTamano());
        } else {
            System.out.println("[Error] No se registró: el ticket ya existe o los datos no son válidos.");
        }
    }

    private static void buscarCliente(ColaAtencion cola) {
        String criterio = leerTexto("Ingrese número de ticket o DNI: ");
        Cliente cliente = cola.buscarCliente(criterio);
        if (cliente == null) System.out.println("No se encontró al cliente.");
        else System.out.println("[Cliente encontrado] " + cliente);
    }

    private static void cancelarTurno(ColaAtencion cola) {
        String ticket = leerTexto("Número de ticket que desea cancelar: ");
        if (cola.eliminarPorTicket(ticket)) {
            System.out.println("[Éxito] Turno " + ticket + " cancelado.");
        } else {
            System.out.println("[Aviso] No existe ese ticket en la cola.");
        }
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return teclado.nextLine().trim();
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String entrada = teclado.nextLine().trim();
            try {
                return Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }
}
