ACTIVIDAD 2 - SISTEMA ACADÉMICO

Proyecto Java con 21 opciones:
1. Registrar estudiante
2. Listar estudiantes
3. Buscar estudiante
4. Modificar estudiante
5. Eliminar estudiante
6. Registrar curso
7. Listar cursos
8. Buscar curso
9. Modificar curso
10. Eliminar curso
11. Registrar matrícula
12. Listar matrículas
13. Consultar cursos de estudiante
14. Modificar nota
15. Eliminar matrícula
16. Promedio de estudiante
17. Ranking académico
18. Estudiantes por carrera
19. Estudiantes desaprobados
20. Mejor promedio
21. Salir

Clase principal: Vista.AplicaAcademico
