package Modelo;

public class Matricula {
    private String codigo;
    private Estudiante estudiante;
    private Curso curso;
    private double nota;

    public Matricula(String codigo, Estudiante estudiante, Curso curso, double nota) {
        this.codigo = codigo;
        this.estudiante = estudiante;
        this.curso = curso;
        this.nota = nota;
    }

    public String getCodigo() {
        return codigo;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }
}
