package com.frank.expedientes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/** Interfaz gráfica para administrar expedientes académicos. */
public class Main extends JFrame {
    private final ArbolExpedientes arbol = new ArbolExpedientes();
    private final JTextField txtCodigo = new JTextField(8);
    private final JTextField txtNombre = new JTextField(18);
    private final JComboBox<String> cbEstado = new JComboBox<>(new String[]{"Pendiente", "En revisión", "Aprobado", "Observado", "Archivado"});
    private final JTextField txtBuscar = new JTextField(10);
    private final JTextField txtCriterio = new JTextField(12);
    private final DefaultTableModel modelo = new DefaultTableModel(new String[]{"Código", "Estudiante", "Estado"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable tabla = new JTable(modelo);
    private final JLabel lblResumen = new JLabel("Total: 0 | Altura del árbol: 0");

    public Main() {
        super("Sistema de Gestión de Expedientes Académicos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 540);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        JPanel registro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        registro.setBorder(BorderFactory.createTitledBorder("Registrar expediente"));
        registro.add(new JLabel("Código:")); registro.add(txtCodigo);
        registro.add(new JLabel("Estudiante:")); registro.add(txtNombre);
        registro.add(new JLabel("Estado:")); registro.add(cbEstado);
        JButton btnRegistrar = new JButton("Registrar");
        registro.add(btnRegistrar);
        add(registro, BorderLayout.NORTH);

        tabla.setFillsViewportHeight(true);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel acciones = new JPanel(new GridLayout(0, 1, 4, 4));
        JPanel fila1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnListar = new JButton("Mostrar orden ascendente");
        JButton btnBuscar = new JButton("Buscar por código");
        fila1.add(btnListar); fila1.add(new JLabel("Código:")); fila1.add(txtBuscar); fila1.add(btnBuscar);
        JPanel fila2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnContar = new JButton("Contar por criterio");
        fila2.add(new JLabel("Criterio (nombre/estado):")); fila2.add(txtCriterio); fila2.add(btnContar);
        JPanel fila3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnTodo = new JButton("Mostrar todos");
        fila3.add(btnTodo); fila3.add(lblResumen);
        acciones.add(fila1); acciones.add(fila2); acciones.add(fila3);
        add(acciones, BorderLayout.SOUTH);

        btnRegistrar.addActionListener(e -> registrar());
        btnListar.addActionListener(e -> mostrar(arbol.listarAscendente()));
        btnTodo.addActionListener(e -> mostrar(arbol.listarAscendente()));
        btnBuscar.addActionListener(e -> buscar());
        btnContar.addActionListener(e -> contarCriterio());
        actualizarResumen();
    }

    private void registrar() {
        try {
            int codigo = Integer.parseInt(txtCodigo.getText().trim());
            Expediente expediente = new Expediente(codigo, txtNombre.getText(), (String) cbEstado.getSelectedItem());
            if (!arbol.insertar(expediente)) {
                JOptionPane.showMessageDialog(this, "Ya existe un expediente con ese código.", "Código duplicado", JOptionPane.WARNING_MESSAGE);
                return;
            }
            txtCodigo.setText(""); txtNombre.setText("");
            mostrar(arbol.listarAscendente());
            actualizarResumen();
            JOptionPane.showMessageDialog(this, "Expediente registrado correctamente.");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "El código debe ser un número entero.", "Dato inválido", JOptionPane.ERROR_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Dato inválido", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscar() {
        try {
            int codigo = Integer.parseInt(txtBuscar.getText().trim());
            Expediente encontrado = arbol.buscar(codigo);
            if (encontrado == null) {
                JOptionPane.showMessageDialog(this, "No se encontró un expediente con código " + codigo + ".");
            } else {
                mostrar(java.util.Collections.singletonList(encontrado));
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un código válido para buscar.");
        }
    }

    private void contarCriterio() {
        String criterio = txtCriterio.getText().trim();
        if (criterio.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escriba un nombre o estado como criterio.");
            return;
        }
        int total = arbol.contarPorCriterio(criterio);
        JOptionPane.showMessageDialog(this, "Expedientes que coinciden con «" + criterio + "»: " + total);
    }

    private void mostrar(List<Expediente> expedientes) {
        modelo.setRowCount(0);
        for (Expediente e : expedientes)
            modelo.addRow(new Object[]{e.getCodigo(), e.getNombreEstudiante(), e.getEstado()});
    }

    private void actualizarResumen() {
        lblResumen.setText("Total: " + arbol.contar() + " | Altura del árbol: " + arbol.altura());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
