# Proyecto 1: Sistema de Gestión y Análisis de Archivos de una Empresa

Aplicación Java de escritorio para analizar directorios y subdirectorios de forma recursiva. Diseñada para abrirse como proyecto Java en Apache NetBeans.

## Requisitos
- JDK 8 o superior.
- Apache NetBeans (cualquier versión compatible con el JDK instalado).

## Cómo ejecutar en NetBeans
1. Descomprime el ZIP.
2. En NetBeans, selecciona **File > Open Project** si reconoce el proyecto; si no, usa **File > New Project > Java with Ant > Java Application** y selecciona/importa la carpeta `src`.
3. La clase principal es `vista.Main`.
4. Ejecuta el proyecto. Pulsa **Seleccionar carpeta** para elegir la carpeta que deseas analizar.

También puedes compilar desde una terminal ubicada en la carpeta del proyecto:
```bash
javac -encoding UTF-8 -d build/classes src/modelo/*.java src/dao/*.java src/servicio/*.java src/vista/*.java
java -cp build/classes vista.Main
```

## Funcionalidades
1. Seleccionar la carpeta raíz.
2. Listar archivos y subcarpetas.
3. Contar archivos accesibles.
4. Calcular el tamaño total de archivos accesibles.
5. Buscar archivos por nombre o extensión.
6. Generar un reporte de cantidades por tipo/extensión.
7. Mostrar la estructura jerárquica de directorios.

## Arquitectura
- `modelo`: clases de datos.
- `dao`: acceso al sistema de archivos.
- `servicio`: algoritmos recursivos y reglas de análisis.
- `vista`: interfaz gráfica Swing y clase principal.

## Decisiones técnicas
- Las rutas se tratan como `Path`/`File`; no se modifica ni elimina ningún archivo.
- Los errores de acceso a carpetas se registran como advertencias y no detienen todo el análisis.
- Los resultados se devuelven en colecciones no modificables para proteger el estado interno.
- Los directorios simbólicos no se siguen deliberadamente para evitar ciclos recursivos.
- El tamaño se expresa en bytes; la interfaz también presenta una aproximación legible.

## Estructura de prueba
La carpeta `prueba/` contiene archivos ficticios de ejemplo (sin información real). Selecciónala desde la aplicación para comprobar los resultados.
