package Modelo;

/** Entidad que representa a un alumno registrado en el sistema. */
public class Alumno {
    private String codigo;
    private String nombre;
    private int edad;
    private double promedio;

    public Alumno() { }

    public Alumno(String codigo, String nombre, int edad, double promedio) {
        setCodigo(codigo);
        setNombre(nombre);
        setEdad(edad);
        setPromedio(promedio);
    }

    public String getCodigo() { return codigo; }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código es obligatorio.");
        }
        this.codigo = codigo.trim();
    }

    public String getNombre() { return nombre; }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio.");
        }
        this.nombre = nombre.trim();
    }

    public int getEdad() { return edad; }

    public void setEdad(int edad) {
        if (edad < 1 || edad > 120) {
            throw new IllegalArgumentException("La edad debe estar entre 1 y 120.");
        }
        this.edad = edad;
    }

    public double getPromedio() { return promedio; }

    public void setPromedio(double promedio) {
        if (!Double.isFinite(promedio) || promedio < 0 || promedio > 20) {
            throw new IllegalArgumentException("El promedio debe estar entre 0 y 20.");
        }
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return String.format("Código: %s | Nombre: %s | Edad: %d | Promedio: %.2f",
                codigo, nombre, edad, promedio);
    }
}
