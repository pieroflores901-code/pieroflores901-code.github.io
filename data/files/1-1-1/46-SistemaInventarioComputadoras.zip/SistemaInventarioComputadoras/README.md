# Sistema Avanzado de Gestión de Inventario de Computadoras

Aplicación de consola en Java para Apache NetBeans. Implementa una pila dinámica (LIFO) mediante una lista simplemente enlazada y separa el código en los paquetes `modelo`, `dao` y `vista`.

## Requisitos
- JDK 8 o superior.
- Apache NetBeans con soporte para proyectos Java.

## Abrir en NetBeans
1. Descomprima `SistemaInventarioComputadoras.zip`.
2. En NetBeans, seleccione **File > Open Project** y elija la carpeta `SistemaInventarioComputadoras`.
3. Ejecute el proyecto con **Run Project**. La clase principal es `vista.Main`.

Si NetBeans no reconoce automáticamente la carpeta como proyecto, cree un proyecto **Java Application** llamado `SistemaInventarioComputadoras` y copie la carpeta `src` dentro del proyecto. Seleccione `vista.Main` como clase principal.

## Opciones
1. Apilar computadora.
2. Mostrar inventario desde la cima hasta la base.
3. Desapilar / despachar la computadora más reciente (con control de pila vacía).
4. Consultar la cima sin retirarla.
5. Limpiar el inventario.
6. Contar computadoras.
7. Buscar por número de serie e indicar posición desde la cima (posición inicial 1).
8. Calcular el valor total.
9. Mostrar equipos cuyo precio sea estrictamente mayor al límite indicado.
10. Mostrar la computadora más cara.
11. Salir.

## Estructura
- `modelo.Computadora`: entidad, atributos, constructores, getters/setters y `toString()`.
- `modelo.Nodo`: almacena una computadora y referencia al siguiente nodo.
- `dao.PilaInventario`: administra la cima y los nodos de la pila dinámica.
- `vista.Main`: menú repetitivo e interacción por consola.

La información se mantiene en memoria durante la ejecución; al cerrar la aplicación, el inventario no se guarda en disco.
