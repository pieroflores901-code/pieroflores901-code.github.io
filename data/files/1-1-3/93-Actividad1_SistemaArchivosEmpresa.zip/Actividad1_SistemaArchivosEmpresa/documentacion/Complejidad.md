# Análisis de complejidad temporal y espacial

Definiciones:
- **N**: cantidad total de archivos y directorios visitados.
- **D**: profundidad máxima del árbol de directorios.
- **K**: cantidad de elementos que coinciden con una búsqueda.

| Operación | Tiempo estimado | Espacio adicional |
|---|---:|---:|
| Recorrido recursivo | O(N log N) en el peor caso por ordenar los hijos de cada directorio; O(N) si no se considera el ordenamiento | O(N) para almacenar resultados y O(D) de pila recursiva |
| Contar archivos | O(N) | O(1) |
| Calcular tamaño total | O(N) | O(1) |
| Buscar por nombre | O(N) | O(K) para la lista de coincidencias y O(N) de pila en la versión recursiva |
| Buscar por extensión | O(N) | O(K) para coincidencias y O(N) de pila en la versión recursiva |
| Reporte por tipo | O(N log T), aproximadamente, por el mapa ordenado; T es la cantidad de tipos distintos | O(T) |
| Mostrar estructura | O(N log N) en el peor caso por ordenar los hijos | O(D) de pila, más el texto de salida |

## Observaciones
- El recorrido usa recursividad real para visitar subdirectorios.
- Las búsquedas también usan métodos recursivos que recorren la colección de resultados.
- En árboles extremadamente profundos, la recursividad puede agotar la pila de Java (`StackOverflowError`). Para árboles no confiables o profundidades enormes, se recomienda una estrategia iterativa.
- El acceso a carpetas puede fallar por permisos, desconexión de unidades o cambios durante el análisis. Esos casos se manejan con advertencias cuando es posible.
- No se siguen enlaces simbólicos como directorios, para reducir el riesgo de ciclos.
