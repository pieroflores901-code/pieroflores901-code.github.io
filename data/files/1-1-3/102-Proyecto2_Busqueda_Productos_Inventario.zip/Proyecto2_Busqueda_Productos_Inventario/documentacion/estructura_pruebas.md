# Estructura y casos de prueba

## Estructura de carpetas
```text
Proyecto2_Busqueda_Productos_Inventario/
├── src/
│   └── inventario/
│       ├── Main.java
│       ├── Producto.java
│       └── Inventario.java
├── documentacion/
│   ├── diagrama_flujo.md
│   ├── analisis_complejidad.md
│   └── estructura_pruebas.md
├── pruebas/
│   └── casos_prueba.md
└── README.md
```

## Casos de prueba sugeridos
1. Registrar un código nuevo con precio y cantidad válidos: debe aceptarse.
2. Registrar un código repetido: debe mostrar error.
3. Registrar precio negativo o cantidad negativa: debe rechazarse.
4. Buscar `P120`: debe encontrar “Teclado mecánico”.
5. Buscar un código inexistente: debe indicar que no se encontró.
6. Calcular valor total con datos demo: debe mostrar S/ 20,977.70.
7. Calcular unidades con datos demo: debe mostrar 13.
8. Listar sin existencias: debe mostrar P120 y P140.
9. Reporte con límite 3: debe mostrar P110 y P130.
10. Inventario sin coincidencias en un reporte: debe mostrar “No hay productos para mostrar”.
