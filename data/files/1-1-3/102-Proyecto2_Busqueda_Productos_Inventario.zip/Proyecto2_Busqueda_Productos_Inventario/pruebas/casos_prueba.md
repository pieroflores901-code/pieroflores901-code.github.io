# Casos de prueba

| ID | Acción | Entrada / condición | Resultado esperado |
|---|---|---|---|
| CP-01 | Registrar | Código P150, descripción Cámara, precio 350, cantidad 4 | Registro exitoso |
| CP-02 | Duplicado | Registrar P100 nuevamente | Error de código existente |
| CP-03 | Precio inválido | Precio -5 | Se rechaza |
| CP-04 | Cantidad inválida | Cantidad -2 | Se rechaza |
| CP-05 | Búsqueda exitosa | Código P120 | Encuentra Teclado mecánico |
| CP-06 | Búsqueda fallida | Código X999 | Indica que no existe |
| CP-07 | Valor total | Datos demo iniciales | S/ 20,977.70 |
| CP-08 | Unidades | Datos demo iniciales | 13 unidades |
| CP-09 | Sin existencias | Datos demo iniciales | P120 y P140 |
| CP-10 | Bajo inventario | Límite 3 | P110 y P130 |
