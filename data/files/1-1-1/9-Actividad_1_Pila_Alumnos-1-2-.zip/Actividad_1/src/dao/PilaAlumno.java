package dao;

import modelo.Alumno;

public class PilaAlumno {
    private final Alumno[] alumnos;
    private int tope;

    public PilaAlumno(int capacidad) {
        if (capacidad <= 0) throw new IllegalArgumentException("La capacidad debe ser positiva.");
        alumnos = new Alumno[capacidad];
        tope = -1;
    }

    public boolean estaVacia() { return tope == -1; }
    public boolean estaLlena() { return tope == alumnos.length - 1; }

    public boolean insertarPila(Alumno alumno) {
        if (estaLlena()) {
            System.out.println("Pila llena. No se puede insertar (Overflow)."); return false;
        }
        if (alumno == null || alumno.getCodigo() == null || alumno.getCodigo().trim().isEmpty()
                || alumno.getNombre() == null || alumno.getNombre().trim().isEmpty()
                || alumno.getEdad() <= 0 || !Double.isFinite(alumno.getPromedio())
                || alumno.getPromedio() < 0 || alumno.getPromedio() > 20) {
            System.out.println("Datos del alumno no válidos."); return false;
        }
        String codigo = alumno.getCodigo().trim();
        for (int i = tope; i >= 0; i--) {
            if (alumnos[i].getCodigo().equalsIgnoreCase(codigo)) {
                System.out.println("El código ya está registrado."); return false;
            }
        }
        alumno.setCodigo(codigo);
        alumno.setNombre(alumno.getNombre().trim());
        alumnos[++tope] = alumno;
        System.out.println("Alumno insertado en la cima."); return true;
    }

    public void mostrarPila() {
        if (estaVacia()) { System.out.println("Pila vacía."); return; }
        int posicion = 1;
        for (int i = tope; i >= 0; i--)
            System.out.println(posicion++ + ". " + alumnos[i]);
    }

    public Alumno eliminaDatos() {
        if (estaVacia()) {
            System.out.println("Pila vacía. No se puede extraer (Underflow)."); return null;
        }
        Alumno retirado = alumnos[tope];
        alumnos[tope] = null;
        tope--;
        System.out.println("Alumno extraído: " + retirado); return retirado;
    }

    public void eliminaPila() {
        while (tope >= 0) {
            alumnos[tope] = null;
            tope--;
        }
        System.out.println("Pila vaciada. Conserva su capacidad original.");
    }

    public Alumno consultarCima() {
        if (estaVacia()) { System.out.println("Pila vacía."); return null; }
        System.out.println("Cima: " + alumnos[tope]); return alumnos[tope];
    }

    public void mostrarEstadoCapacidad() {
        int actuales = tope + 1;
        System.out.println("Capacidad total: " + alumnos.length);
        System.out.println("Alumnos almacenados: " + actuales);
        System.out.println("Espacios libres: " + (alumnos.length - actuales));
    }

    public Alumno buscarAlumnoPorCodigo(String codigo) {
        if (estaVacia()) { System.out.println("Pila vacía."); return null; }
        if (codigo != null) {
            for (int i = tope; i >= 0; i--) {
                if (alumnos[i].getCodigo().equalsIgnoreCase(codigo.trim())) {
                    System.out.println("Posición desde la cima: " + (tope - i + 1));
                    System.out.println(alumnos[i]); return alumnos[i];
                }
            }
        }
        System.out.println("Alumno no encontrado."); return null;
    }

    public void verificarEstadoLogico() {
        System.out.println("¿Pila vacía?: " + estaVacia());
        System.out.println("¿Pila llena?: " + estaLlena());
    }

    public Alumno mostrarMejorPromedio() {
        if (estaVacia()) { System.out.println("Pila vacía. No hay promedios."); return null; }
        Alumno mejor = alumnos[tope];
        for (int i = tope - 1; i >= 0; i--)
            if (alumnos[i].getPromedio() > mejor.getPromedio()) mejor = alumnos[i];
        System.out.println("Alumno con mejor promedio: " + mejor); return mejor;
    }
}
