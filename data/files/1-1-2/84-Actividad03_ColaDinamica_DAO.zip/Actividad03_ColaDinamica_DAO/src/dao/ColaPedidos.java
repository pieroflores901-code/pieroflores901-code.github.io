package dao;

import modelo.Nodo;
import modelo.Pedido;

/**
 * DAO/estructura de datos: cola dinámica FIFO implementada con nodos.
 * front apunta al primer pedido y fin al último.
 */
public class ColaPedidos {
    private Nodo frente;
    private Nodo fin;
    private int tamanio;

    public ColaPedidos() {
        frente = null;
        fin = null;
        tamanio = 0;
    }

    /** 1. Registra un pedido al final de la cola. */
    public void encolar(Pedido pedido) {
        if (pedido == null) throw new IllegalArgumentException("El pedido no puede ser nulo.");
        Nodo nuevo = new Nodo(pedido);
        if (estaVacia()) {
            frente = nuevo;
            fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
        tamanio++;
    }

    /** 2. Retira el pedido más antiguo y lo devuelve. */
    public Pedido desencolar() {
        if (estaVacia()) return null;
        Pedido pedidoRetirado = frente.getPedido();
        frente = frente.getSiguiente();
        tamanio--;
        if (frente == null) fin = null;
        return pedidoRetirado;
    }

    /** 3. Consulta el pedido que está al frente, sin retirarlo. */
    public Pedido consultarSiguiente() {
        return estaVacia() ? null : frente.getPedido();
    }

    /** 4. Devuelve todos los pedidos en orden FIFO, sin modificar la cola. */
    public String listarPendientes() {
        if (estaVacia()) return "No hay pedidos pendientes.";
        StringBuilder resultado = new StringBuilder();
        Nodo actual = frente;
        int posicion = 1;
        while (actual != null) {
            resultado.append(posicion++).append(". ")
                     .append(actual.getPedido()).append(System.lineSeparator());
            actual = actual.getSiguiente();
        }
        return resultado.toString();
    }

    /** 5. Indica si la cola está vacía. */
    public boolean estaVacia() {
        return frente == null;
    }

    /** 6. Busca un pedido por código o por nombre de cliente, sin alterar enlaces. */
    public Pedido buscar(String criterio) {
        if (criterio == null || criterio.trim().isEmpty()) return null;
        String busqueda = criterio.trim();
        Nodo actual = frente;
        while (actual != null) {
            Pedido pedido = actual.getPedido();
            if (pedido.getCodigo().equalsIgnoreCase(busqueda)
                    || pedido.getNombreCliente().equalsIgnoreCase(busqueda)) {
                return pedido;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    /** 7. Suma el monto total de todos los pedidos pendientes. */
    public double calcularTotalAcumulado() {
        double total = 0.0;
        Nodo actual = frente;
        while (actual != null) {
            total += actual.getPedido().getMontoTotal();
            actual = actual.getSiguiente();
        }
        return total;
    }

    /** 8. Cancela un pedido por código y reajusta los enlaces de la lista. */
    public Pedido cancelarPorCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty() || estaVacia()) return null;

        String buscado = codigo.trim();
        Nodo actual = frente;
        Nodo anterior = null;

        while (actual != null) {
            if (actual.getPedido().getCodigo().equalsIgnoreCase(buscado)) {
                if (anterior == null) {
                    frente = actual.getSiguiente();
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                }

                if (actual == fin) fin = anterior;
                tamanio--;

                if (frente == null) fin = null;
                actual.setSiguiente(null);
                return actual.getPedido();
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }
        return null;
    }

    public int getTamanio() { return tamanio; }
}
