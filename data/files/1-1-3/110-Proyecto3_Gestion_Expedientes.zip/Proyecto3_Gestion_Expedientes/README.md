# Proyecto 3: Sistema de Gestión de Expedientes y Documentos Académicos

Aplicación Java Swing para Apache NetBeans. Organiza los expedientes en un árbol binario de búsqueda (ABB) por código.

## Requisitos
- JDK 8 o superior.
- Apache NetBeans con soporte Maven.

## Abrir y ejecutar
1. Descomprime el ZIP.
2. En NetBeans selecciona **File > Open Project** y elige la carpeta `Proyecto3_Gestion_Expedientes`.
3. Ejecuta el proyecto. La clase principal es `com.frank.expedientes.Main`.
4. Si NetBeans no ejecuta directamente el proyecto Maven, abre `Main.java` y usa **Run File**.

## Funciones implementadas
1. Registrar código, nombre del estudiante y estado.
2. Insertar en un ABB recursivamente; los códigos duplicados se rechazan.
3. Buscar un expediente por código.
4. Listar expedientes en orden ascendente mediante recorrido inorden.
5. Contar expedientes recursivamente.
6. Calcular altura recursivamente (árbol vacío = 0, un nodo = 1).
7. Contar expedientes cuyo nombre o estado contiene un criterio, ignorando mayúsculas/minúsculas.

## Diagrama de flujo (resumen)
Inicio → ingresar código, estudiante y estado → validar datos → ¿código existente?
- Sí → mostrar aviso de código duplicado.
- No → insertar recursivamente en el ABB → actualizar listado, total y altura → fin.

## Pruebas sugeridas
Registrar (30, Ana Pérez, Pendiente), (10, Luis Rojas, Aprobado), (20, María Díaz, En revisión).
- Mostrar orden ascendente: 10, 20, 30.
- Buscar código 20: muestra María Díaz.
- Contar por criterio `aprobado`: 1.
- Total: 3.
- Altura: 3 para el orden de inserción sugerido.

## Análisis de complejidad
Sea `n` el número de expedientes y `h` la altura del árbol:
- Insertar: O(h), promedio O(log n), peor caso O(n).
- Buscar por código: O(h), promedio O(log n), peor caso O(n).
- Listar en orden ascendente: O(n).
- Contar nodos: O(n).
- Calcular altura: O(n).
- Contar por criterio (nombre/estado): O(n).
El ABB no está balanceado automáticamente; su altura depende del orden de inserción.

## Estructura
- `Expediente.java`: modelo de datos.
- `Nodo.java`: nodo del árbol.
- `ArbolExpedientes.java`: operaciones recursivas del ABB.
- `Main.java`: interfaz gráfica.
