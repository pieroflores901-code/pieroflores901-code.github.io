package modelo;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Resultado agregado de un análisis, sin exponer colecciones modificables. */
public final class ResultadoAnalisis {
    private final Path raiz;
    private final List<ArchivoInfo> elementos;
    private final List<String> advertencias;

    public ResultadoAnalisis(Path raiz, List<ArchivoInfo> elementos, List<String> advertencias) {
        this.raiz = raiz.toAbsolutePath().normalize();
        this.elementos = Collections.unmodifiableList(new ArrayList<ArchivoInfo>(elementos));
        this.advertencias = Collections.unmodifiableList(new ArrayList<String>(advertencias));
    }

    public Path getRaiz() { return raiz; }
    public List<ArchivoInfo> getElementos() { return elementos; }
    public List<String> getAdvertencias() { return advertencias; }

    public long contarArchivos() {
        long total = 0;
        for (ArchivoInfo info : elementos) if (!info.isDirectorio()) total++;
        return total;
    }

    public long contarDirectorios() {
        long total = 0;
        for (ArchivoInfo info : elementos) if (info.isDirectorio()) total++;
        return total;
    }

    public long calcularTamanoTotal() {
        long total = 0;
        for (ArchivoInfo info : elementos) {
            if (!info.isDirectorio()) {
                long tamano = info.getTamanoBytes();
                if (Long.MAX_VALUE - total < tamano) return Long.MAX_VALUE;
                total += tamano;
            }
        }
        return total;
    }

    public Map<String, Long> contarPorTipo() {
        Map<String, Long> conteo = new TreeMap<String, Long>();
        for (ArchivoInfo info : elementos) {
            if (!info.isDirectorio()) {
                String tipo = info.getExtension();
                Long actual = conteo.get(tipo);
                conteo.put(tipo, actual == null ? 1L : actual + 1L);
            }
        }
        return Collections.unmodifiableMap(conteo);
    }
}
