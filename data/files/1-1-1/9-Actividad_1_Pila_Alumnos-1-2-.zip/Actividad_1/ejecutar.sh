#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
mkdir -p build
javac -encoding UTF-8 -d build src/modelo/*.java src/dao/*.java src/vista/*.java
java -cp build vista.AplicaAlumno
