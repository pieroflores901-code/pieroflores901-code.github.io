package vista;

import dao.ColaPedidos;
import modelo.Pedido;

import java.util.Scanner;

/**
 * Interfaz de consola para el sistema de gestión de pedidos de cocina.
 */
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final ColaPedidos cola = new ColaPedidos();

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1: registrarPedido(); break;
                    case 2: despacharPedido(); break;
                    case 3: consultarSiguiente(); break;
                    case 4: mostrarPendientes(); break;
                    case 5: verificarVacia(); break;
                    case 6: buscarPedido(); break;
                    case 7: mostrarTotal(); break;
                    case 8: cancelarPedido(); break;
                    case 0: System.out.println("Sistema finalizado."); break;
                    default: System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("Dato inválido: " + ex.getMessage());
            }
            if (opcion != 0) {
                System.out.println();
                System.out.print("Presione ENTER para continuar...");
                SC.nextLine();
            }
        } while (opcion != 0);
        SC.close();
    }

    private static void mostrarMenu() {
        System.out.println("==============================================");
        System.out.println("  SISTEMA DE GESTIÓN DE PEDIDOS DE COCINA");
        System.out.println("       Cola dinámica + patrón DAO");
        System.out.println("==============================================");
        System.out.println("1. Registrar / encolar pedido");
        System.out.println("2. Despachar / desencolar pedido");
        System.out.println("3. Consultar siguiente pedido");
        System.out.println("4. Mostrar pedidos pendientes");
        System.out.println("5. Verificar si la cola está vacía");
        System.out.println("6. Buscar pedido por código o cliente");
        System.out.println("7. Calcular monto total acumulado");
        System.out.println("8. Cancelar pedido por código");
        System.out.println("0. Salir");
    }

    private static void registrarPedido() {
        System.out.println("--- REGISTRAR PEDIDO ---");
        String codigo = leerTexto("Código del pedido: ");
        if (cola.buscar(codigo) != null) {
            System.out.println("Ya existe un pedido pendiente con ese código.");
            return;
        }
        String cliente = leerTexto("Nombre del cliente: ");
        String platillo = leerTexto("Descripción del platillo: ");
        double monto = leerDouble("Monto total (S/): ");
        String tipo = leerTexto("Tipo de comida (entrada/fondo/postre/bebida/otro): ");
        Pedido pedido = new Pedido(codigo, cliente, platillo, monto, tipo);
        cola.encolar(pedido);
        System.out.println("Pedido registrado y agregado al final de la cola.");
    }

    private static void despacharPedido() {
        Pedido pedido = cola.desencolar();
        if (pedido == null) System.out.println("No se puede despachar: la cola está vacía.");
        else System.out.println("Pedido despachado:\n" + pedido);
    }

    private static void consultarSiguiente() {
        Pedido pedido = cola.consultarSiguiente();
        if (pedido == null) System.out.println("No hay pedidos para preparar.");
        else System.out.println("Siguiente pedido (el más antiguo):\n" + pedido);
    }

    private static void mostrarPendientes() {
        System.out.println("--- PEDIDOS PENDIENTES (" + cola.getTamanio() + ") ---");
        System.out.print(cola.listarPendientes());
    }

    private static void verificarVacia() {
        System.out.println(cola.estaVacia()
                ? "La cola está vacía. No hay pedidos pendientes."
                : "La cola contiene " + cola.getTamanio() + " pedido(s).");
    }

    private static void buscarPedido() {
        String criterio = leerTexto("Ingrese el código o nombre exacto del cliente: ");
        Pedido pedido = cola.buscar(criterio);
        if (pedido == null) System.out.println("No se encontró el pedido pendiente.");
        else System.out.println("Pedido encontrado:\n" + pedido);
    }

    private static void mostrarTotal() {
        System.out.printf("Monto acumulado de pedidos pendientes: S/ %.2f%n",
                cola.calcularTotalAcumulado());
    }

    private static void cancelarPedido() {
        String codigo = leerTexto("Código del pedido que desea cancelar: ");
        Pedido cancelado = cola.cancelarPorCodigo(codigo);
        if (cancelado == null) System.out.println("No se encontró un pedido pendiente con ese código.");
        else System.out.println("Pedido cancelado correctamente:\n" + cancelado);
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return SC.nextLine().trim();
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = SC.nextLine().trim();
            try { return Integer.parseInt(texto); }
            catch (NumberFormatException ex) { System.out.println("Ingrese un número entero."); }
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = SC.nextLine().trim().replace(',', '.');
            try {
                double valor = Double.parseDouble(texto);
                if (valor < 0 || Double.isNaN(valor) || Double.isInfinite(valor)) {
                    System.out.println("Ingrese un monto válido no negativo.");
                } else return valor;
            } catch (NumberFormatException ex) {
                System.out.println("Ingrese un monto numérico, por ejemplo 25.50.");
            }
        }
    }
}
