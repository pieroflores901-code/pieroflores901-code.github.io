package Vista;

import DAO.ColaAlumno;
import Modelo.Alumno;
import java.util.List;
import java.util.Scanner;

/** Vista de consola: menú e interacción con el usuario. */
public class Principal {
    private static final Scanner teclado = new Scanner(System.in);
    private static ColaAlumno cola;

    public static void main(String[] args) {
        System.out.println("==============================================");
        System.out.println(" SISTEMA DE GESTIÓN DE ALUMNOS - COLA FIFO");
        System.out.println(" Arquitectura Modelo / DAO / Vista");
        System.out.println("==============================================");

        int capacidad = leerEnteroPositivo("Ingrese la capacidad máxima de la cola: ");
        cola = new ColaAlumno(capacidad);
        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1: insertarAlumno(); break;
                    case 2: eliminarFrente(); break;
                    case 3: consultarFrente(); break;
                    case 4: cola.mostrarTodos(); break;
                    case 5:
                        System.out.println(cola.estaVacia() ? "La cola está vacía." : "La cola no está vacía.");
                        break;
                    case 6:
                        System.out.println(cola.estaLlena() ? "La cola está llena." : "Hay espacio disponible.");
                        break;
                    case 7:
                        System.out.println("Cantidad: " + cola.tamanio() + " de " + cola.capacidad());
                        break;
                    case 8: buscarPorCodigo(); break;
                    case 9:
                        System.out.printf("Promedio general del grupo: %.2f%n", cola.calcularPromedioGeneral());
                        break;
                    case 10: filtrarPorPromedio(); break;
                    case 11:
                        System.out.println("Mayor promedio: " + cola.obtenerMayorPromedio());
                        System.out.println("Menor promedio: " + cola.obtenerMenorPromedio());
                        break;
                    case 12:
                        cola.invertirOrden();
                        System.out.println("Orden invertido correctamente.");
                        cola.mostrarTodos();
                        break;
                    case 13: eliminarPorCodigo(); break;
                    case 0: System.out.println("Fin del programa."); break;
                    default: System.out.println("Opción no válida. Intente nuevamente.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (opcion != 0);
        teclado.close();
    }

    private static void mostrarMenu() {
        System.out.println("\\n============== MENÚ PRINCIPAL ==============");
        System.out.println(" 1. Encolar / insertar alumno");
        System.out.println(" 2. Desencolar / eliminar alumno del frente");
        System.out.println(" 3. Consultar alumno del frente");
        System.out.println(" 4. Mostrar todos los alumnos (FIFO)");
        System.out.println(" 5. Verificar si la cola está vacía");
        System.out.println(" 6. Verificar si la cola está llena");
        System.out.println(" 7. Mostrar cantidad de alumnos");
        System.out.println(" 8. Buscar alumno por código");
        System.out.println(" 9. Calcular promedio general");
        System.out.println("10. Filtrar alumnos por promedio mínimo");
        System.out.println("11. Mostrar mayor y menor promedio");
        System.out.println("12. Invertir el orden de la cola");
        System.out.println("13. Eliminar alumno por código");
        System.out.println(" 0. Salir");
        System.out.println("============================================");
    }

    private static void insertarAlumno() {
        if (cola.estaLlena()) throw new IllegalStateException("No se puede insertar: la cola está llena.");
        String codigo = leerTexto("Código: ");
        if (cola.buscarPorCodigo(codigo) != null) {
            throw new IllegalArgumentException("Ya existe un alumno con ese código.");
        }
        String nombre = leerTexto("Nombre completo: ");
        int edad = leerEntero("Edad (1-120): ");
        double promedio = leerDecimal("Promedio (0-20): ");
        cola.insertar(new Alumno(codigo, nombre, edad, promedio));
        System.out.println("Alumno registrado correctamente.");
    }

    private static void eliminarFrente() {
        System.out.println("Alumno retirado: " + cola.eliminar());
    }

    private static void consultarFrente() {
        System.out.println("Alumno ubicado al frente: " + cola.consultar());
    }

    private static void buscarPorCodigo() {
        String codigo = leerTexto("Ingrese el código a buscar: ");
        Alumno alumno = cola.buscarPorCodigo(codigo);
        System.out.println(alumno == null ? "No se encontró un alumno con ese código." : "Alumno encontrado: " + alumno);
    }

    private static void filtrarPorPromedio() {
        double minimo = leerDecimal("Promedio mínimo (0-20): ");
        List<Alumno> resultado = cola.filtrarPorPromedio(minimo);
        if (resultado.isEmpty()) {
            System.out.println("No hay alumnos que cumplan el criterio.");
        } else {
            System.out.println("--- ALUMNOS QUE CUMPLEN EL CRITERIO ---");
            for (Alumno alumno : resultado) System.out.println(alumno);
        }
    }

    private static void eliminarPorCodigo() {
        String codigo = leerTexto("Código del alumno que desea eliminar: ");
        Alumno eliminado = cola.eliminarPorCodigo(codigo);
        System.out.println(eliminado == null
                ? "No se encontró un alumno con ese código."
                : "Alumno eliminado: " + eliminado);
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) return texto;
            System.out.println("El campo no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero válido.");
            }
        }
    }

    private static int leerEnteroPositivo(String mensaje) {
        while (true) {
            int valor = leerEntero(mensaje);
            if (valor > 0) return valor;
            System.out.println("La capacidad debe ser mayor que cero.");
        }
    }

    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                double valor = Double.parseDouble(teclado.nextLine().trim().replace(',', '.'));
                if (Double.isFinite(valor)) return valor;
                System.out.println("Ingrese un número decimal finito.");
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número decimal válido.");
            }
        }
    }
}
