package DAO;

import Modelo.Alumno;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * DAO que administra una cola estática circular de alumnos.
 * Mantiene el orden FIFO para las operaciones habituales.
 */
public class ColaAlumno {
    private final Alumno[] alumnos;
    private int frente;
    private int finalCola;
    private int cantidad;

    public ColaAlumno(int capacidad) {
        if (capacidad <= 0) {
            throw new IllegalArgumentException("La capacidad debe ser mayor que cero.");
        }
        alumnos = new Alumno[capacidad];
        frente = 0;
        finalCola = -1;
        cantidad = 0;
    }

    public boolean estaVacia() { return cantidad == 0; }
    public boolean estaLlena() { return cantidad == alumnos.length; }
    public int tamanio() { return cantidad; }
    public int capacidad() { return alumnos.length; }

    public void insertar(Alumno alumno) {
        if (alumno == null) {
            throw new IllegalArgumentException("El alumno no puede ser null.");
        }
        if (estaLlena()) {
            throw new IllegalStateException("Overflow: la cola está llena.");
        }
        finalCola = (finalCola + 1) % alumnos.length;
        alumnos[finalCola] = alumno;
        cantidad++;
    }

    /** Elimina y devuelve el elemento del frente (FIFO). */
    public Alumno eliminar() {
        if (estaVacia()) {
            throw new IllegalStateException("Underflow: la cola está vacía.");
        }
        Alumno alumno = alumnos[frente];
        alumnos[frente] = null;
        frente = (frente + 1) % alumnos.length;
        cantidad--;
        if (cantidad == 0) {
            frente = 0;
            finalCola = -1;
        }
        return alumno;
    }

    /** Consulta el frente sin eliminarlo. */
    public Alumno consultar() {
        if (estaVacia()) {
            throw new IllegalStateException("La cola está vacía.");
        }
        return alumnos[frente];
    }

    public void mostrarTodos() {
        if (estaVacia()) {
            System.out.println("No hay alumnos registrados.");
            return;
        }
        System.out.println("\\n--- ALUMNOS EN ORDEN FIFO ---");
        for (int i = 0; i < cantidad; i++) {
            System.out.println((i + 1) + ". " + alumnos[(frente + i) % alumnos.length]);
        }
    }

    /** Busca por código utilizando una cola auxiliar y restaura el orden original. */
    public Alumno buscarPorCodigo(String codigo) {
        validarCodigo(codigo);
        ColaAlumno auxiliar = new ColaAlumno(capacidad());
        Alumno encontrado = null;

        while (!estaVacia()) {
            Alumno actual = eliminar();
            auxiliar.insertar(actual);
            if (encontrado == null && actual.getCodigo().equalsIgnoreCase(codigo.trim())) {
                encontrado = actual;
            }
        }
        while (!auxiliar.estaVacia()) {
            insertar(auxiliar.eliminar());
        }
        return encontrado;
    }

    public double calcularPromedioGeneral() {
        if (estaVacia()) {
            throw new IllegalStateException("No hay alumnos para calcular el promedio.");
        }
        double suma = 0;
        for (int i = 0; i < cantidad; i++) {
            suma += alumnos[(frente + i) % alumnos.length].getPromedio();
        }
        return suma / cantidad;
    }

    /** Devuelve en una lista los alumnos cuyo promedio es mayor o igual al mínimo indicado. */
    public List<Alumno> filtrarPorPromedio(double minimo) {
        validarPromedio(minimo);
        List<Alumno> resultado = new ArrayList<>();
        for (int i = 0; i < cantidad; i++) {
            Alumno alumno = alumnos[(frente + i) % alumnos.length];
            if (alumno.getPromedio() >= minimo) {
                resultado.add(alumno);
            }
        }
        return resultado;
    }

    public Alumno obtenerMayorPromedio() {
        if (estaVacia()) {
            throw new IllegalStateException("No hay alumnos registrados.");
        }
        Alumno mejor = consultar();
        for (int i = 1; i < cantidad; i++) {
            Alumno actual = alumnos[(frente + i) % alumnos.length];
            if (actual.getPromedio() > mejor.getPromedio()) mejor = actual;
        }
        return mejor;
    }

    public Alumno obtenerMenorPromedio() {
        if (estaVacia()) {
            throw new IllegalStateException("No hay alumnos registrados.");
        }
        Alumno menor = consultar();
        for (int i = 1; i < cantidad; i++) {
            Alumno actual = alumnos[(frente + i) % alumnos.length];
            if (actual.getPromedio() < menor.getPromedio()) menor = actual;
        }
        return menor;
    }

    /** Invierte el orden de los alumnos usando una pila auxiliar. */
    public void invertirOrden() {
        Stack<Alumno> pila = new Stack<>();
        while (!estaVacia()) pila.push(eliminar());
        while (!pila.empty()) insertar(pila.pop());
    }

    /** Elimina la primera coincidencia por código y conserva el orden de los demás. */
    public Alumno eliminarPorCodigo(String codigo) {
        validarCodigo(codigo);
        ColaAlumno auxiliar = new ColaAlumno(capacidad());
        Alumno eliminado = null;

        while (!estaVacia()) {
            Alumno actual = eliminar();
            if (eliminado == null && actual.getCodigo().equalsIgnoreCase(codigo.trim())) {
                eliminado = actual;
            } else {
                auxiliar.insertar(actual);
            }
        }
        while (!auxiliar.estaVacia()) insertar(auxiliar.eliminar());
        return eliminado;
    }

    private void validarCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda es obligatorio.");
        }
    }

    private void validarPromedio(double promedio) {
        if (!Double.isFinite(promedio) || promedio < 0 || promedio > 20) {
            throw new IllegalArgumentException("El promedio mínimo debe estar entre 0 y 20.");
        }
    }
}
