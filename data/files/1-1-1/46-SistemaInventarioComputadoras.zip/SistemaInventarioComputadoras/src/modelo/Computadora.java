package modelo;

import java.util.Locale;

/**
 * Entidad que representa una computadora del inventario.
 */
public class Computadora {
    private String numeroSerie;
    private String marca;
    private String modelo;
    private String procesador;
    private int memoriaRAM;
    private double precio;

    public Computadora(String numeroSerie, String marca, String modelo,
                       String procesador, int memoriaRAM, double precio) {
        setNumeroSerie(numeroSerie);
        setMarca(marca);
        setModelo(modelo);
        setProcesador(procesador);
        setMemoriaRAM(memoriaRAM);
        setPrecio(precio);
    }

    public String getNumeroSerie() { return numeroSerie; }
    public void setNumeroSerie(String numeroSerie) {
        if (numeroSerie == null || numeroSerie.trim().isEmpty())
            throw new IllegalArgumentException("El número de serie es obligatorio.");
        this.numeroSerie = numeroSerie.trim();
    }

    public String getMarca() { return marca; }
    public void setMarca(String marca) {
        if (marca == null || marca.trim().isEmpty())
            throw new IllegalArgumentException("La marca es obligatoria.");
        this.marca = marca.trim();
    }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) {
        if (modelo == null || modelo.trim().isEmpty())
            throw new IllegalArgumentException("El modelo es obligatorio.");
        this.modelo = modelo.trim();
    }

    public String getProcesador() { return procesador; }
    public void setProcesador(String procesador) {
        if (procesador == null || procesador.trim().isEmpty())
            throw new IllegalArgumentException("El procesador es obligatorio.");
        this.procesador = procesador.trim();
    }

    public int getMemoriaRAM() { return memoriaRAM; }
    public void setMemoriaRAM(int memoriaRAM) {
        if (memoriaRAM <= 0)
            throw new IllegalArgumentException("La memoria RAM debe ser mayor que cero.");
        this.memoriaRAM = memoriaRAM;
    }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) {
        if (!Double.isFinite(precio) || precio < 0)
            throw new IllegalArgumentException("El precio no puede ser negativo.");
        this.precio = precio;
    }

    @Override
    public String toString() {
        return String.format(Locale.US,
            "Serie: %s | Marca: %s | Modelo: %s | Procesador: %s | RAM: %d GB | Precio: S/ %.2f",
            numeroSerie, marca, modelo, procesador, memoriaRAM, precio);
    }
}
