package dao;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Acceso controlado al sistema de archivos. No expone nodos ni listas internas.
 */
public class ArchivoDAO {

    /** Devuelve una instantánea inmodificable de los hijos inmediatos. */
    public List<Path> listarHijos(Path directorio) throws IOException {
        if (directorio == null || !Files.isDirectory(directorio, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("La ruta no es un directorio accesible: " + directorio);
        }
        List<Path> hijos = new ArrayList<Path>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directorio)) {
            for (Path hijo : stream) hijos.add(hijo);
        }
        Collections.sort(hijos, (a, b) -> a.getFileName().toString()
                .compareToIgnoreCase(b.getFileName().toString()));
        return Collections.unmodifiableList(hijos);
    }

    public boolean esDirectorio(Path ruta) {
        return ruta != null && Files.isDirectory(ruta, LinkOption.NOFOLLOW_LINKS);
    }

    public boolean esArchivoRegular(Path ruta) {
        return ruta != null && Files.isRegularFile(ruta, LinkOption.NOFOLLOW_LINKS);
    }

    public long obtenerTamano(Path archivo) throws IOException {
        return Files.size(archivo);
    }

    public boolean esLegible(Path ruta) {
        return ruta != null && Files.isReadable(ruta);
    }
}
