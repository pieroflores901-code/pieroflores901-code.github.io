package com.frank.expedientes;

import java.util.ArrayList;
import java.util.List;

/** Árbol binario de búsqueda ordenado por código de expediente. */
public class ArbolExpedientes {
    private Nodo raiz;
    private int cantidad;

    public boolean insertar(Expediente expediente) {
        if (buscar(expediente.getCodigo()) != null) return false;
        raiz = insertarRec(raiz, expediente);
        cantidad++;
        return true;
    }

    private Nodo insertarRec(Nodo actual, Expediente expediente) {
        if (actual == null) return new Nodo(expediente);
        if (expediente.getCodigo() < actual.expediente.getCodigo())
            actual.izquierdo = insertarRec(actual.izquierdo, expediente);
        else if (expediente.getCodigo() > actual.expediente.getCodigo())
            actual.derecho = insertarRec(actual.derecho, expediente);
        return actual;
    }

    public Expediente buscar(int codigo) { return buscarRec(raiz, codigo); }

    private Expediente buscarRec(Nodo actual, int codigo) {
        if (actual == null) return null;
        if (codigo == actual.expediente.getCodigo()) return actual.expediente;
        return codigo < actual.expediente.getCodigo()
                ? buscarRec(actual.izquierdo, codigo)
                : buscarRec(actual.derecho, codigo);
    }

    public List<Expediente> listarAscendente() {
        List<Expediente> resultado = new ArrayList<>();
        inordenRec(raiz, resultado);
        return resultado;
    }

    private void inordenRec(Nodo actual, List<Expediente> resultado) {
        if (actual == null) return;
        inordenRec(actual.izquierdo, resultado);
        resultado.add(actual.expediente);
        inordenRec(actual.derecho, resultado);
    }

    public int contar() { return contarRec(raiz); }
    private int contarRec(Nodo actual) {
        if (actual == null) return 0;
        return 1 + contarRec(actual.izquierdo) + contarRec(actual.derecho);
    }

    /** Altura medida en niveles: árbol vacío=0 y un solo nodo=1. */
    public int altura() { return alturaRec(raiz); }
    private int alturaRec(Nodo actual) {
        if (actual == null) return 0;
        return 1 + Math.max(alturaRec(actual.izquierdo), alturaRec(actual.derecho));
    }

    /** Cuenta expedientes cuyo nombre o estado contiene el criterio (sin distinguir mayúsculas). */
    public int contarPorCriterio(String criterio) {
        if (criterio == null || criterio.trim().isEmpty()) return 0;
        return contarCriterioRec(raiz, criterio.trim().toLowerCase());
    }
    private int contarCriterioRec(Nodo actual, String criterio) {
        if (actual == null) return 0;
        String nombre = actual.expediente.getNombreEstudiante().toLowerCase();
        String estado = actual.expediente.getEstado().toLowerCase();
        int coincide = (nombre.contains(criterio) || estado.contains(criterio)) ? 1 : 0;
        return coincide + contarCriterioRec(actual.izquierdo, criterio)
                        + contarCriterioRec(actual.derecho, criterio);
    }
}
