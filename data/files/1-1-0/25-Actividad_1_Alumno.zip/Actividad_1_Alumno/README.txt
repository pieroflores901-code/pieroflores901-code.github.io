ACTIVIDAD 1 - GESTION DE ALUMNOS CON POO + ARRAYLIST

Paquetes:
Modelo: contiene la clase Alumno.
DAO: contiene la clase DAOAlumno con el ArrayList y los metodos.
Vista: contiene la clase AplicaAlumno con el menu principal.

Metodos adicionales desarrollados:
1. buscarPorNombre()
2. listarPorCarrera()
3. ordenarPorApellidos()
4. ordenarPorEdad()
5. invertirLista()
6. obtenerPrimero()
7. obtenerUltimo()
8. eliminarPorCarrera()
9. contarPorCarrera()
10. mostrarRango()

Para ejecutar:
Abrir el proyecto o copiar la carpeta src en NetBeans.
Ejecutar la clase Vista.AplicaAlumno.
