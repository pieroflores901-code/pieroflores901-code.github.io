package inventario;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final Inventario INVENTARIO = new Inventario();

    public static void main(String[] args) {
        cargarDatosDemo();
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1: registrarProducto(); break;
                    case 2: mostrarProductos(INVENTARIO.listar(), "PRODUCTOS REGISTRADOS"); break;
                    case 3: buscarProducto(); break;
                    case 4: System.out.printf("%nValor total del inventario: S/ %.2f%n", INVENTARIO.valorTotalRecursivo()); break;
                    case 5: System.out.println("\nUnidades disponibles en total: " + INVENTARIO.unidadesTotalesRecursivo()); break;
                    case 6: mostrarProductos(INVENTARIO.sinExistenciasRecursivo(), "PRODUCTOS SIN EXISTENCIAS"); break;
                    case 7:
                        int limite = leerEntero("Mostrar productos con cantidad entre 1 y ¿qué límite?: ");
                        if (limite < 1) System.out.println("El límite debe ser al menos 1.");
                        else mostrarProductos(INVENTARIO.bajoInventarioRecursivo(limite), "REPORTE DE BAJO INVENTARIO (≤ " + limite + ")");
                        break;
                    case 0: System.out.println("¡Hasta luego!"); break;
                    default: System.out.println("Opción no válida.");
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
            if (opcion != 0) System.out.println();
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println("==============================================");
        System.out.println(" PROYECTO 2 - BÚSQUEDA Y ANÁLISIS DE INVENTARIO");
        System.out.println("==============================================");
        System.out.println("1. Registrar producto");
        System.out.println("2. Mostrar productos");
        System.out.println("3. Buscar por código (binaria recursiva)");
        System.out.println("4. Calcular valor total (recursivo)");
        System.out.println("5. Calcular unidades disponibles (recursivo)");
        System.out.println("6. Listar productos sin existencias (recursivo)");
        System.out.println("7. Reporte de bajo inventario (recursivo)");
        System.out.println("0. Salir");
    }

    private static void registrarProducto() {
        System.out.println("\nREGISTRAR PRODUCTO");
        String codigo = leerTexto("Código: ");
        String descripcion = leerTexto("Descripción: ");
        double precio = leerDouble("Precio (S/): ");
        int cantidad = leerEntero("Cantidad disponible: ");
        INVENTARIO.registrar(new Producto(codigo, descripcion, precio, cantidad));
        System.out.println("Producto registrado correctamente.");
    }

    private static void buscarProducto() {
        String codigo = leerTexto("Ingrese el código que desea buscar: ");
        Producto p = INVENTARIO.buscarBinario(codigo);
        if (p == null) System.out.println("No se encontró un producto con código " + codigo.toUpperCase() + ".");
        else {
            System.out.println("\nProducto encontrado:");
            imprimirEncabezado();
            System.out.println(p);
        }
    }

    private static void mostrarProductos(List<Producto> lista, String titulo) {
        System.out.println("\n--- " + titulo + " ---");
        if (lista.isEmpty()) {
            System.out.println("No hay productos para mostrar.");
            return;
        }
        imprimirEncabezado();
        for (Producto p : lista) System.out.println(p);
        System.out.println("Total de registros: " + lista.size());
    }

    private static void imprimirEncabezado() {
        System.out.printf("%-12s | %-30s | %-13s | %-8s | %-14s%n",
                "CÓDIGO", "DESCRIPCIÓN", "PRECIO", "CANTIDAD", "VALOR");
        System.out.println("----------------------------------------------------------------------------------------------");
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return SC.nextLine().trim();
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try { return Integer.parseInt(SC.nextLine().trim()); }
            catch (NumberFormatException ex) { System.out.println("Ingrese un número entero válido."); }
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                String entrada = SC.nextLine().trim().replace(',', '.');
                double valor = Double.parseDouble(entrada);
                if (Double.isFinite(valor) && valor >= 0) return valor;
            } catch (NumberFormatException ignored) { }
            System.out.println("Ingrese un precio válido (cero o mayor).");
        }
    }

    private static void cargarDatosDemo() {
        INVENTARIO.registrar(new Producto("P100", "Laptop Lenovo", 2450.00, 8));
        INVENTARIO.registrar(new Producto("P110", "Mouse inalámbrico", 45.90, 3));
        INVENTARIO.registrar(new Producto("P120", "Teclado mecánico", 189.50, 0));
        INVENTARIO.registrar(new Producto("P130", "Monitor 24 pulgadas", 620.00, 2));
        INVENTARIO.registrar(new Producto("P140", "Audífonos USB", 79.90, 0));
    }
}
