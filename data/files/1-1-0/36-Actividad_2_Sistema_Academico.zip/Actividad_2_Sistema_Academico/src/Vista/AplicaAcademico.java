package Vista;

import DAO.SistemaAcademico;
import Modelo.Curso;
import Modelo.Estudiante;
import Modelo.Matricula;
import java.util.ArrayList;
import java.util.Scanner;

public class AplicaAcademico {
    static Scanner teclado = new Scanner(System.in);
    static SistemaAcademico sistema = new SistemaAcademico();

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            switch (opcion) {
                case 1 -> registrarEstudiante();
                case 2 -> listarEstudiantes();
                case 3 -> buscarEstudiante();
                case 4 -> modificarEstudiante();
                case 5 -> eliminarEstudiante();
                case 6 -> registrarCurso();
                case 7 -> listarCursos();
                case 8 -> buscarCurso();
                case 9 -> modificarCurso();
                case 10 -> eliminarCurso();
                case 11 -> registrarMatricula();
                case 12 -> listarMatriculas();
                case 13 -> consultarCursosEstudiante();
                case 14 -> modificarNota();
                case 15 -> eliminarMatricula();
                case 16 -> promedioEstudiante();
                case 17 -> rankingAcademico();
                case 18 -> estudiantesPorCarrera();
                case 19 -> estudiantesDesaprobados();
                case 20 -> mejorPromedio();
                case 21 -> salir();
                default -> System.out.println("Opción incorrecta");
            }
        } while (opcion != 21);
    }

    public static void mostrarMenu() {
        System.out.println("\nSISTEMA ACADÉMICO");
        System.out.println("\nESTUDIANTES");
        System.out.println("[1] Registrar estudiante");
        System.out.println("[2] Listar estudiantes");
        System.out.println("[3] Buscar estudiante");
        System.out.println("[4] Modificar estudiante");
        System.out.println("[5] Eliminar estudiante");
        System.out.println("\nCURSOS");
        System.out.println("[6] Registrar curso");
        System.out.println("[7] Listar cursos");
        System.out.println("[8] Buscar curso");
        System.out.println("[9] Modificar curso");
        System.out.println("[10] Eliminar curso");
        System.out.println("\nMATRÍCULAS");
        System.out.println("[11] Registrar matrícula");
        System.out.println("[12] Listar matrículas");
        System.out.println("[13] Consultar cursos de estudiante");
        System.out.println("[14] Modificar nota");
        System.out.println("[15] Eliminar matrícula");
        System.out.println("\nREPORTES");
        System.out.println("[16] Promedio de estudiante");
        System.out.println("[17] Ranking académico");
        System.out.println("[18] Estudiantes por carrera");
        System.out.println("[19] Estudiantes desaprobados");
        System.out.println("[20] Mejor promedio");
        System.out.println("[21] Salir");
    }

    public static void registrarEstudiante() {
        String codigo = leerTexto("Código: ");
        String nombres = leerTexto("Nombres: ");
        String apellidos = leerTexto("Apellidos: ");
        String carrera = leerTexto("Carrera: ");
        Estudiante estudiante = new Estudiante(codigo, nombres, apellidos, carrera);
        System.out.println(sistema.registrarEstudiante(estudiante) ? "Estudiante registrado" : "El código ya existe");
    }

    public static void listarEstudiantes() {
        mostrarEstudiantes(sistema.listarEstudiantes());
    }

    public static void buscarEstudiante() {
        Estudiante estudiante = sistema.buscarEstudiante(leerTexto("Código del estudiante: "));
        if (estudiante == null) {
            System.out.println("Estudiante no encontrado");
        } else {
            mostrarEstudiante(estudiante);
        }
    }

    public static void modificarEstudiante() {
        String codigo = leerTexto("Código del estudiante: ");
        String nombres = leerTexto("Nuevos nombres: ");
        String apellidos = leerTexto("Nuevos apellidos: ");
        String carrera = leerTexto("Nueva carrera: ");
        System.out.println(sistema.modificarEstudiante(codigo, nombres, apellidos, carrera)
                ? "Estudiante modificado" : "Estudiante no encontrado");
    }

    public static void eliminarEstudiante() {
        String codigo = leerTexto("Código del estudiante: ");
        System.out.println(sistema.eliminarEstudiante(codigo)
                ? "Estudiante eliminado" : "Estudiante no encontrado");
    }

    public static void registrarCurso() {
        String codigo = leerTexto("Código: ");
        String nombre = leerTexto("Nombre: ");
        int creditos = leerEnteroPositivo("Créditos: ");
        Curso curso = new Curso(codigo, nombre, creditos);
        System.out.println(sistema.registrarCurso(curso) ? "Curso registrado" : "El código ya existe");
    }

    public static void listarCursos() {
        mostrarCursos(sistema.listarCursos());
    }

    public static void buscarCurso() {
        Curso curso = sistema.buscarCurso(leerTexto("Código del curso: "));
        if (curso == null) {
            System.out.println("Curso no encontrado");
        } else {
            mostrarCurso(curso);
        }
    }

    public static void modificarCurso() {
        String codigo = leerTexto("Código del curso: ");
        String nombre = leerTexto("Nuevo nombre: ");
        int creditos = leerEnteroPositivo("Nuevos créditos: ");
        System.out.println(sistema.modificarCurso(codigo, nombre, creditos)
                ? "Curso modificado" : "Curso no encontrado");
    }

    public static void eliminarCurso() {
        String codigo = leerTexto("Código del curso: ");
        System.out.println(sistema.eliminarCurso(codigo) ? "Curso eliminado" : "Curso no encontrado");
    }

    public static void registrarMatricula() {
        String codigoEstudiante = leerTexto("Código del estudiante: ");
        String codigoCurso = leerTexto("Código del curso: ");
        double nota = leerNota("Nota: ");
        int resultado = sistema.registrarMatricula(codigoEstudiante, codigoCurso, nota);
        if (resultado == 1) {
            System.out.println("Matrícula registrada");
        } else if (resultado == -1) {
            System.out.println("El estudiante ya está matriculado en el curso");
        } else {
            System.out.println("Estudiante o curso no encontrado");
        }
    }

    public static void listarMatriculas() {
        mostrarMatriculas(sistema.listarMatriculas());
    }

    public static void consultarCursosEstudiante() {
        String codigo = leerTexto("Código del estudiante: ");
        mostrarMatriculas(sistema.consultarCursosEstudiante(codigo));
    }

    public static void modificarNota() {
        String codigo = leerTexto("Código de matrícula: ");
        double nota = leerNota("Nueva nota: ");
        System.out.println(sistema.modificarNota(codigo, nota)
                ? "Nota modificada" : "Matrícula no encontrada");
    }

    public static void eliminarMatricula() {
        String codigo = leerTexto("Código de matrícula: ");
        System.out.println(sistema.eliminarMatricula(codigo)
                ? "Matrícula eliminada" : "Matrícula no encontrada");
    }

    public static void promedioEstudiante() {
        String codigo = leerTexto("Código del estudiante: ");
        double promedio = sistema.promedioEstudiante(codigo);
        if (promedio < 0) {
            System.out.println("El estudiante no tiene matrículas");
        } else {
            System.out.printf("Promedio: %.2f%n", promedio);
        }
    }

    public static void rankingAcademico() {
        ArrayList<Estudiante> ranking = sistema.rankingAcademico();
        if (ranking.isEmpty()) {
            System.out.println("No hay promedios registrados");
            return;
        }
        int puesto = 1;
        for (Estudiante estudiante : ranking) {
            System.out.printf("%d. %s %s - %.2f%n", puesto, estudiante.getNombres(),
                    estudiante.getApellidos(), sistema.promedioEstudiante(estudiante.getCodigo()));
            puesto++;
        }
    }

    public static void estudiantesPorCarrera() {
        String carrera = leerTexto("Carrera: ");
        mostrarEstudiantes(sistema.estudiantesPorCarrera(carrera));
    }

    public static void estudiantesDesaprobados() {
        mostrarMatriculas(sistema.estudiantesDesaprobados());
    }

    public static void mejorPromedio() {
        Estudiante estudiante = sistema.mejorPromedio();
        if (estudiante == null) {
            System.out.println("No hay promedios registrados");
        } else {
            mostrarEstudiante(estudiante);
            System.out.printf("Promedio: %.2f%n", sistema.promedioEstudiante(estudiante.getCodigo()));
        }
    }

    public static void salir() {
        System.out.println("Programa finalizado");
    }

    public static void mostrarEstudiante(Estudiante estudiante) {
        System.out.println(estudiante.getCodigo() + " | " + estudiante.getNombres() + " | "
                + estudiante.getApellidos() + " | " + estudiante.getCarrera());
    }

    public static void mostrarEstudiantes(ArrayList<Estudiante> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay estudiantes para mostrar");
            return;
        }
        for (Estudiante estudiante : lista) {
            mostrarEstudiante(estudiante);
        }
    }

    public static void mostrarCurso(Curso curso) {
        System.out.println(curso.getCodigo() + " | " + curso.getNombre() + " | " + curso.getCreditos() + " créditos");
    }

    public static void mostrarCursos(ArrayList<Curso> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay cursos para mostrar");
            return;
        }
        for (Curso curso : lista) {
            mostrarCurso(curso);
        }
    }

    public static void mostrarMatriculas(ArrayList<Matricula> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay matrículas para mostrar");
            return;
        }
        for (Matricula matricula : lista) {
            System.out.println(matricula.getCodigo() + " | "
                    + matricula.getEstudiante().getNombres() + " "
                    + matricula.getEstudiante().getApellidos() + " | "
                    + matricula.getCurso().getNombre() + " | Nota: " + matricula.getNota());
        }
    }

    public static String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
        } while (texto.isEmpty());
        return texto;
    }

    public static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número entero");
            }
        }
    }

    public static int leerEnteroPositivo(String mensaje) {
        int numero;
        do {
            numero = leerEntero(mensaje);
            if (numero <= 0) {
                System.out.println("El valor debe ser mayor que cero");
            }
        } while (numero <= 0);
        return numero;
    }

    public static double leerNota(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                double nota = Double.parseDouble(teclado.nextLine().trim());
                if (nota >= 0 && nota <= 20) {
                    return nota;
                }
                System.out.println("La nota debe estar entre 0 y 20");
            } catch (NumberFormatException e) {
                System.out.println("Ingrese una nota válida");
            }
        }
    }
}
