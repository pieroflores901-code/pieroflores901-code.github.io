# Diagrama de flujo: recorrido recursivo

```text
                 ┌────────────────────────┐
                 │ Inicio                 │
                 └───────────┬────────────┘
                             v
                 ┌────────────────────────┐
                 │ Seleccionar carpeta    │
                 └───────────┬────────────┘
                             v
                 ┌────────────────────────┐
                 │ ¿Es carpeta válida?    │
                 └───────┬────────┬───────┘
                       No         Sí
                        v          v
                ┌────────────┐  ┌───────────────────┐
                │ Mostrar    │  │ Listar hijos      │
                │ advertencia│  │ del directorio    │
                └─────┬──────┘  └─────────┬─────────┘
                      │                   v
                      │          ┌─────────────────────┐
                      │          │ ¿Quedan hijos?      │
                      │          └─────┬────────┬──────┘
                      │               No       Sí
                      │                v        v
                      │       ┌────────────┐ ┌────────────────┐
                      │       │ Retornar   │ │ Tomar siguiente│
                      │       └─────┬──────┘ │ hijo           │
                      │             │        └───────┬────────┘
                      │             │                v
                      │             │       ┌────────────────┐
                      │             │       │ ¿Es directorio?│
                      │             │       └───┬────────┬───┘
                      │             │          Sí       No
                      │             │           v        v
                      │             │  ┌──────────────┐ ┌─────────────┐
                      │             │  │ Registrar    │ │ Registrar   │
                      │             │  │ directorio   │ │ archivo y   │
                      │             │  └──────┬───────┘ │ tamaño      │
                      │             │         v         └──────┬──────┘
                      │             │  ┌──────────────┐        │
                      │             │  │ Recorrer hijo│        │
                      │             │  │ recursivamente│       │
                      │             │  └──────┬───────┘        │
                      │             └─────────┴────────────────┘
                      │                       │
                      └───────────────────────┘
                              v
                 ┌────────────────────────┐
                 │ Mostrar resultados     │
                 └───────────┬────────────┘
                             v
                 ┌────────────────────────┐
                 │ Fin                     │
                 └────────────────────────┘
```

**Caso base:** el directorio no contiene hijos que procesar, o no se puede acceder a él.  
**Caso recursivo:** por cada subdirectorio, se vuelve a invocar el recorrido para analizar su contenido.
