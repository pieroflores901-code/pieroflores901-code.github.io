package modelo;

public class Alumno {
    private String codigo;
    private String nombre;
    private int edad;
    private double promedio;

    public Alumno() { }

    public Alumno(String codigo, String nombre, int edad, double promedio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.edad = edad;
        this.promedio = promedio;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public double getPromedio() { return promedio; }
    public void setPromedio(double promedio) { this.promedio = promedio; }

    @Override
    public String toString() {
        return String.format("Código: %s | Nombre: %s | Edad: %d | Promedio: %.2f", codigo, nombre, edad, promedio);
    }
}
