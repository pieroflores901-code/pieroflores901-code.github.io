package inventario;

public class Producto {
    private final String codigo;
    private final String descripcion;
    private final double precio;
    private int cantidad;

    public Producto(String codigo, String descripcion, double precio, int cantidad) {
        if (codigo == null || codigo.trim().isEmpty()) throw new IllegalArgumentException("El código es obligatorio.");
        if (descripcion == null || descripcion.trim().isEmpty()) throw new IllegalArgumentException("La descripción es obligatoria.");
        if (precio < 0) throw new IllegalArgumentException("El precio no puede ser negativo.");
        if (cantidad < 0) throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        this.codigo = codigo.trim().toUpperCase();
        this.descripcion = descripcion.trim();
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getCodigo() { return codigo; }
    public String getDescripcion() { return descripcion; }
    public double getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) {
        if (cantidad < 0) throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        this.cantidad = cantidad;
    }
    public double getValorInventario() { return precio * cantidad; }

    @Override
    public String toString() {
        return String.format("%-12s | %-30s | S/ %10.2f | %8d | S/ %12.2f",
                codigo, descripcion, precio, cantidad, getValorInventario());
    }
}
