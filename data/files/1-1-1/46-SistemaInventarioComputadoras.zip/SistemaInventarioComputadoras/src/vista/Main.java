package vista;

import dao.PilaInventario;
import modelo.Computadora;
import java.util.Scanner;

/**
 * Vista de consola. Ejecutar esta clase para iniciar la aplicación.
 */
public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final PilaInventario inventario = new PilaInventario();

    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            switch (opcion) {
                case 1: apilar(); break;
                case 2: inventario.mostrarInventario(); break;
                case 3: desapilar(); break;
                case 4: consultarCima(); break;
                case 5: limpiar(); break;
                case 6:
                    System.out.println("Total de computadoras almacenadas: " + inventario.contarComputadoras());
                    break;
                case 7: buscarPorSerie(); break;
                case 8:
                    System.out.printf("Valor monetario total del inventario: S/ %.2f%n",
                            inventario.calcularValorInventario());
                    break;
                case 9:
                    double limite = leerDouble("Ingrese el precio límite (S/): ");
                    inventario.mostrarEquiposSuperioresA(limite);
                    break;
                case 10: mostrarMasCaro(); break;
                case 11:
                    System.out.println("Saliendo del sistema. ¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción inválida. Seleccione una opción del 1 al 11.");
            }
            if (opcion != 11) pausar();
        } while (opcion != 11);
        SC.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n==============================================");
        System.out.println(" SISTEMA DE GESTIÓN DE INVENTARIO (PILA DINÁMICA)");
        System.out.println("==============================================");
        System.out.println("1. Apilar computadora (ingresar equipo)");
        System.out.println("2. Mostrar inventario");
        System.out.println("3. Desapilar / despachar computadora");
        System.out.println("4. Consultar cima");
        System.out.println("5. Limpiar todo el inventario");
        System.out.println("----------------------------------------------");
        System.out.println("6. Contar total de computadoras");
        System.out.println("7. Buscar computadora por número de serie");
        System.out.println("8. Calcular valor monetario total");
        System.out.println("9. Mostrar equipos superiores a un precio límite");
        System.out.println("10. Mostrar la computadora más cara");
        System.out.println("11. Salir");
        System.out.println("==============================================");
    }

    private static void apilar() {
        System.out.println("\n--- INGRESO DE COMPUTADORA ---");
        String serie = leerTexto("Número de serie: ");
        // Evita duplicar identificadores dentro del inventario.
        if (inventario.buscarPorSerie(serie) != null) {
            System.out.println("Ya existe una computadora con ese número de serie.");
            return;
        }
        String marca = leerTexto("Marca: ");
        String modelo = leerTexto("Modelo: ");
        String procesador = leerTexto("Procesador: ");
        int ram = leerEnteroPositivo("Memoria RAM (GB): ");
        double precio = leerDoubleNoNegativo("Precio (S/): ");
        try {
            Computadora computadora = new Computadora(serie, marca, modelo, procesador, ram, precio);
            inventario.apilarComputadora(computadora);
            System.out.println("Computadora ingresada correctamente en la cima de la pila.");
        } catch (IllegalArgumentException ex) {
            System.out.println("No se pudo registrar: " + ex.getMessage());
        }
    }

    private static void desapilar() {
        Computadora retirada = inventario.desapilarComputadora();
        if (retirada == null) {
            System.out.println("Underflow: no se puede despachar; el inventario está vacío.");
        } else {
            System.out.println("Computadora despachada: " + retirada);
        }
    }

    private static void consultarCima() {
        Computadora cima = inventario.consultarCima();
        if (cima == null) System.out.println("El inventario está vacío.");
        else System.out.println("Computadora en la cima (sin retirarla):\n" + cima);
    }

    private static void limpiar() {
        if (inventario.estaVacia()) {
            System.out.println("El inventario ya está vacío.");
            return;
        }
        String confirmacion = leerTexto("¿Está seguro de eliminar todos los equipos? (S/N): ");
        if (confirmacion.equalsIgnoreCase("S")) {
            inventario.limpiarInventario();
            System.out.println("Inventario limpiado correctamente.");
        } else {
            System.out.println("Operación cancelada.");
        }
    }

    private static void buscarPorSerie() {
        String serie = leerTexto("Ingrese el número de serie que desea buscar: ");
        Computadora encontrada = inventario.buscarPorSerie(serie);
        int posicion = inventario.posicionPorSerie(serie);
        if (encontrada == null) {
            System.out.println("No se encontró una computadora con la serie " + serie + ".");
        } else {
            System.out.println("Computadora encontrada: " + encontrada);
            System.out.println("Posición relativa desde la cima: " + posicion);
        }
    }

    private static void mostrarMasCaro() {
        Computadora c = inventario.obtenerEquipoMasCaro();
        if (c == null) System.out.println("El inventario está vacío.");
        else System.out.println("Computadora con el precio más alto:\n" + c);
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = SC.nextLine().trim();
            if (!valor.isEmpty()) return valor;
            System.out.println("El dato no puede estar vacío.");
        }
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = SC.nextLine().trim();
            try { return Integer.parseInt(valor); }
            catch (NumberFormatException ex) { System.out.println("Ingrese un número entero válido."); }
        }
    }

    private static int leerEnteroPositivo(String mensaje) {
        while (true) {
            int valor = leerEntero(mensaje);
            if (valor > 0) return valor;
            System.out.println("El valor debe ser mayor que cero.");
        }
    }

    private static double leerDouble(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = SC.nextLine().trim().replace(',', '.');
            try {
                double numero = Double.parseDouble(valor);
                if (Double.isFinite(numero)) return numero;
            } catch (NumberFormatException ignored) { }
            System.out.println("Ingrese un número válido.");
        }
    }

    private static double leerDoubleNoNegativo(String mensaje) {
        while (true) {
            double valor = leerDouble(mensaje);
            if (valor >= 0) return valor;
            System.out.println("El precio no puede ser negativo.");
        }
    }

    private static void pausar() {
        System.out.print("\nPresione ENTER para continuar...");
        SC.nextLine();
    }
}
