package Vista;

import DAO.DAOAlumno;
import Modelo.Alumno;
import java.util.ArrayList;
import java.util.Scanner;

public class AplicaAlumno {

    static Scanner teclado = new Scanner(System.in);
    static DAOAlumno dao = new DAOAlumno();

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        int op;
        do {
            System.out.println("\n\tMenu de Opciones");
            System.out.println("[1] Ingresar datos del alumno");
            System.out.println("[2] Listar datos de los alumnos");
            System.out.println("[3] Buscar datos del alumno por codigo");
            System.out.println("[4] Modificar datos del alumno");
            System.out.println("[5] Eliminar alumno");
            System.out.println("[6] Buscar alumno por nombre");
            System.out.println("[7] Listar alumnos por carrera");
            System.out.println("[8] Ordenar por apellidos");
            System.out.println("[9] Ordenar por edad");
            System.out.println("[10] Invertir lista");
            System.out.println("[11] Obtener primer alumno");
            System.out.println("[12] Obtener ultimo alumno");
            System.out.println("[13] Eliminar alumnos por carrera");
            System.out.println("[14] Contar alumnos por carrera");
            System.out.println("[15] Mostrar alumnos por rango");
            System.out.println("[0] Salir");
            System.out.print("Ingrese una opcion: ");
            op = teclado.nextInt();
            teclado.nextLine();

            switch (op) {
                case 1:
                    ingresarAlumno();
                    break;
                case 2:
                    listarAlumnos();
                    break;
                case 3:
                    buscarAlumno();
                    break;
                case 4:
                    modificarAlumno();
                    break;
                case 5:
                    eliminarAlumno();
                    break;
                case 6:
                    buscarPorNombre();
                    break;
                case 7:
                    listarPorCarrera();
                    break;
                case 8:
                    ordenarPorApellidos();
                    break;
                case 9:
                    ordenarPorEdad();
                    break;
                case 10:
                    invertirLista();
                    break;
                case 11:
                    obtenerPrimero();
                    break;
                case 12:
                    obtenerUltimo();
                    break;
                case 13:
                    eliminarPorCarrera();
                    break;
                case 14:
                    contarPorCarrera();
                    break;
                case 15:
                    mostrarRango();
                    break;
                case 0:
                    System.out.println("\nPrograma finalizado...");
                    break;
                default:
                    System.out.println("\nOpcion incorrecta.");
            }
        } while (op != 0);
    }

    public static void ingresarAlumno() {
        System.out.println("\nINGRESAR DATOS DEL ALUMNO");
        System.out.print("Ingrese codigo: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        if (dao.buscar(codigo) != null) {
            System.out.println("El codigo ya existe.");
            return;
        }

        System.out.print("Ingrese nombres: ");
        String nombres = teclado.nextLine();
        System.out.print("Ingrese apellidos: ");
        String apellidos = teclado.nextLine();
        System.out.print("Ingrese edad: ");
        int edad = teclado.nextInt();
        teclado.nextLine();
        System.out.print("Ingrese carrera: ");
        String carrera = teclado.nextLine();

        Alumno alumno = new Alumno(codigo, nombres, apellidos, edad, carrera);
        dao.agregar(alumno);
        System.out.println("\nAlumno registrado correctamente.");
    }

    public static void listarAlumnos() {
        System.out.println("\nLISTADO DE ALUMNOS");
        mostrarLista(dao.listar());
        System.out.println("\nTotal de alumnos: " + dao.cantidadAlumnos());
    }

    public static void buscarAlumno() {
        System.out.println("\nBUSCAR ALUMNO POR CODIGO");
        System.out.print("Ingrese codigo del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        Alumno alumno = dao.buscar(codigo);
        if (alumno != null) {
            System.out.println("\nAlumno encontrado:");
            System.out.println(alumno);
        } else {
            System.out.println("\nAlumno no encontrado.");
        }
    }

    public static void modificarAlumno() {
        System.out.println("\nMODIFICAR ALUMNO");
        System.out.print("Ingrese codigo del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        Alumno alumno = dao.buscar(codigo);
        if (alumno == null) {
            System.out.println("\nAlumno no encontrado.");
            return;
        }

        System.out.println("\nDatos actuales:");
        System.out.println(alumno);
        System.out.println("\nIngrese los nuevos datos:");
        System.out.print("Nombres: ");
        String nombres = teclado.nextLine();
        System.out.print("Apellidos: ");
        String apellidos = teclado.nextLine();
        System.out.print("Edad: ");
        int edad = teclado.nextInt();
        teclado.nextLine();
        System.out.print("Carrera: ");
        String carrera = teclado.nextLine();

        Alumno alumnoNuevo = new Alumno(codigo, nombres, apellidos, edad, carrera);
        if (dao.modificar(codigo, alumnoNuevo)) {
            System.out.println("\nAlumno modificado correctamente.");
        } else {
            System.out.println("\nNo se pudo modificar el alumno.");
        }
    }

    public static void eliminarAlumno() {
        System.out.println("\nELIMINAR ALUMNO");
        System.out.print("Ingrese codigo del alumno: ");
        int codigo = teclado.nextInt();
        teclado.nextLine();

        Alumno alumno = dao.buscar(codigo);
        if (alumno == null) {
            System.out.println("\nAlumno no encontrado.");
            return;
        }

        System.out.println("\nAlumno encontrado:");
        System.out.println(alumno);
        System.out.print("\nEsta seguro de eliminarlo? (S/N): ");
        String respuesta = teclado.nextLine();

        if (respuesta.equalsIgnoreCase("S")) {
            if (dao.eliminar(codigo)) {
                System.out.println("\nAlumno eliminado correctamente.");
            }
        } else {
            System.out.println("\nOperacion cancelada.");
        }
    }

    public static void buscarPorNombre() {
        System.out.println("\nBUSCAR ALUMNO POR NOMBRE");
        System.out.print("Ingrese nombre a buscar: ");
        String nombre = teclado.nextLine();
        mostrarLista(dao.buscarPorNombre(nombre));
    }

    public static void listarPorCarrera() {
        System.out.println("\nLISTAR ALUMNOS POR CARRERA");
        System.out.print("Ingrese carrera: ");
        String carrera = teclado.nextLine();
        mostrarLista(dao.listarPorCarrera(carrera));
    }

    public static void ordenarPorApellidos() {
        dao.ordenarPorApellidos();
        System.out.println("\nLista ordenada alfabeticamente por apellidos.");
        mostrarLista(dao.listar());
    }

    public static void ordenarPorEdad() {
        dao.ordenarPorEdad();
        System.out.println("\nLista ordenada por edad.");
        mostrarLista(dao.listar());
    }

    public static void invertirLista() {
        dao.invertirLista();
        System.out.println("\nLista invertida correctamente.");
        mostrarLista(dao.listar());
    }

    public static void obtenerPrimero() {
        Alumno alumno = dao.obtenerPrimero();
        if (alumno == null) {
            System.out.println("\nNo existen alumnos registrados.");
        } else {
            System.out.println("\nPrimer alumno:");
            System.out.println(alumno);
        }
    }

    public static void obtenerUltimo() {
        Alumno alumno = dao.obtenerUltimo();
        if (alumno == null) {
            System.out.println("\nNo existen alumnos registrados.");
        } else {
            System.out.println("\nUltimo alumno:");
            System.out.println(alumno);
        }
    }

    public static void eliminarPorCarrera() {
        System.out.println("\nELIMINAR ALUMNOS POR CARRERA");
        System.out.print("Ingrese carrera: ");
        String carrera = teclado.nextLine();
        int eliminados = dao.eliminarPorCarrera(carrera);
        System.out.println("\nCantidad de alumnos eliminados: " + eliminados);
    }

    public static void contarPorCarrera() {
        System.out.println("\nCONTAR ALUMNOS POR CARRERA");
        System.out.print("Ingrese carrera: ");
        String carrera = teclado.nextLine();
        int cantidad = dao.contarPorCarrera(carrera);
        System.out.println("\nCantidad de alumnos encontrados: " + cantidad);
    }

    public static void mostrarRango() {
        System.out.println("\nMOSTRAR ALUMNOS POR RANGO");
        System.out.print("Ingrese posicion inicial: ");
        int inicio = teclado.nextInt();
        System.out.print("Ingrese posicion final: ");
        int fin = teclado.nextInt();
        teclado.nextLine();

        ArrayList<Alumno> rango = dao.mostrarRango(inicio, fin);
        if (rango.isEmpty()) {
            System.out.println("\nRango incorrecto o no existen alumnos en ese rango.");
        } else {
            mostrarLista(rango);
        }
    }

    public static void mostrarLista(ArrayList<Alumno> lista) {
        if (lista.isEmpty()) {
            System.out.println("No existen alumnos para mostrar.");
            return;
        }
        for (Alumno alumno : lista) {
            System.out.println(alumno);
        }
    }
}
