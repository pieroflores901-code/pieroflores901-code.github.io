# Diagrama de flujo: búsqueda binaria recursiva

```mermaid
flowchart TD
    A([Inicio]) --> B[Ordenar productos por código]
    B --> C[Definir izquierda = 0 y derecha = n - 1]
    C --> D{¿izquierda > derecha?}
    D -- Sí --> E[Retornar no encontrado]
    D -- No --> F[Calcular medio = izquierda + (derecha - izquierda) / 2]
    F --> G{¿Código en medio = buscado?}
    G -- Sí --> H[Retornar producto]
    G -- No --> I{¿Código medio > buscado?}
    I -- Sí --> J[Llamar recursivamente con derecha = medio - 1]
    I -- No --> K[Llamar recursivamente con izquierda = medio + 1]
    J --> D
    K --> D
    E --> L([Fin])
    H --> L
```

## Recorrido de las funciones recursivas
- **Valor total:** suma `precio × cantidad` de cada producto; caso base: índice fuera de la lista, retorna 0.
- **Unidades:** suma la cantidad de cada producto; caso base: índice fuera de la lista, retorna 0.
- **Sin existencias:** examina cada producto y agrega los que tienen cantidad 0; caso base: fin de lista.
- **Bajo inventario:** examina cada producto y agrega los que tienen cantidad entre 1 y el límite indicado; caso base: fin de lista.
