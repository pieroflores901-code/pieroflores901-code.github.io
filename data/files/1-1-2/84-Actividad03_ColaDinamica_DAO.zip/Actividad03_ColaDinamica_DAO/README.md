# Actividad 03 — Sistema de Gestión de Pedidos de Cocina

Aplicación de consola en Java que administra pedidos pendientes mediante una cola dinámica FIFO implementada con nodos, separada en paquetes `modelo`, `dao` y `vista`.

## Estructura

- `modelo/Pedido.java`: entidad con atributos, constructores, getters/setters y `toString()`.
- `modelo/Nodo.java`: nodo que contiene un pedido y la referencia al siguiente nodo.
- `dao/ColaPedidos.java`: estructura dinámica y las ocho operaciones solicitadas.
- `vista/Main.java`: menú interactivo de consola.

## Requisitos

Java JDK 8 o superior.

## Compilar y ejecutar

Desde la carpeta `Actividad03_ColaDinamica_DAO`:

```bash
javac -d out src/modelo/*.java src/dao/*.java src/vista/*.java
java -cp out vista.Main
```

En Windows también se pueden ejecutar los mismos comandos desde CMD o PowerShell, estando dentro de la carpeta del proyecto.

## Operaciones implementadas

1. Registrar / encolar pedido.
2. Despachar / desencolar pedido.
3. Consultar siguiente pedido sin retirarlo.
4. Mostrar todos los pedidos en orden FIFO.
5. Verificar si la cola está vacía.
6. Buscar por código o nombre de cliente.
7. Calcular el monto acumulado de pedidos pendientes.
8. Cancelar por código, ajustando los enlaces.

## Decisiones de diseño

- La cola usa `frente` y `fin`; encolar y desencolar son O(1).
- Buscar y cancelar recorren la lista, por lo que son O(n).
- Si se elimina el último nodo, ambos punteros quedan en `null`.
- No se expone directamente ningún nodo desde la interfaz.
- Los datos se mantienen en memoria mientras el programa está ejecutándose.
