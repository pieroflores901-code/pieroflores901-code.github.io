package modelo;

/**
 * Nodo auxiliar de la cola enlazada. Mantiene una referencia al pedido
 * y al siguiente nodo de la estructura.
 */
public class Nodo {
    private Pedido pedido;
    private Nodo siguiente;

    public Nodo(Pedido pedido) {
        this.pedido = pedido;
        this.siguiente = null;
    }

    public Pedido getPedido() { return pedido; }
    public void setPedido(Pedido pedido) { this.pedido = pedido; }

    public Nodo getSiguiente() { return siguiente; }
    public void setSiguiente(Nodo siguiente) { this.siguiente = siguiente; }
}
