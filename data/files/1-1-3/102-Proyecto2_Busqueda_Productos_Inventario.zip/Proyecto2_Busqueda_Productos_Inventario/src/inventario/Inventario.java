package inventario;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Inventario {
    private final List<Producto> productos = new ArrayList<>();

    public void registrar(Producto producto) {
        if (buscarLinealPorCodigo(producto.getCodigo()) != null) {
            throw new IllegalArgumentException("Ya existe un producto con ese código.");
        }
        productos.add(producto);
    }

    public List<Producto> listar() {
        ordenarPorCodigo();
        return new ArrayList<>(productos);
    }

    public void ordenarPorCodigo() {
        productos.sort(Comparator.comparing(Producto::getCodigo));
    }

    // Búsqueda binaria recursiva: requiere la colección ordenada por código.
    public Producto buscarBinario(String codigo) {
        ordenarPorCodigo();
        return buscarBinarioRecursivo(codigo.trim().toUpperCase(), 0, productos.size() - 1);
    }

    private Producto buscarBinarioRecursivo(String codigo, int izquierda, int derecha) {
        if (izquierda > derecha) return null;
        int medio = izquierda + (derecha - izquierda) / 2;
        int comparacion = productos.get(medio).getCodigo().compareTo(codigo);
        if (comparacion == 0) return productos.get(medio);
        if (comparacion > 0) return buscarBinarioRecursivo(codigo, izquierda, medio - 1);
        return buscarBinarioRecursivo(codigo, medio + 1, derecha);
    }

    // Solo se usa para validar códigos duplicados al registrar.
    private Producto buscarLinealPorCodigo(String codigo) {
        for (Producto p : productos) if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        return null;
    }

    public double valorTotalRecursivo() {
        return valorTotalRecursivo(0);
    }

    private double valorTotalRecursivo(int indice) {
        if (indice >= productos.size()) return 0.0;
        return productos.get(indice).getValorInventario() + valorTotalRecursivo(indice + 1);
    }

    public int unidadesTotalesRecursivo() {
        return unidadesTotalesRecursivo(0);
    }

    private int unidadesTotalesRecursivo(int indice) {
        if (indice >= productos.size()) return 0;
        return productos.get(indice).getCantidad() + unidadesTotalesRecursivo(indice + 1);
    }

    public List<Producto> sinExistenciasRecursivo() {
        List<Producto> resultado = new ArrayList<>();
        sinExistenciasRecursivo(0, resultado);
        return resultado;
    }

    private void sinExistenciasRecursivo(int indice, List<Producto> resultado) {
        if (indice >= productos.size()) return;
        if (productos.get(indice).getCantidad() == 0) resultado.add(productos.get(indice));
        sinExistenciasRecursivo(indice + 1, resultado);
    }

    public List<Producto> bajoInventarioRecursivo(int limite) {
        List<Producto> resultado = new ArrayList<>();
        bajoInventarioRecursivo(0, limite, resultado);
        return resultado;
    }

    private void bajoInventarioRecursivo(int indice, int limite, List<Producto> resultado) {
        if (indice >= productos.size()) return;
        Producto p = productos.get(indice);
        if (p.getCantidad() > 0 && p.getCantidad() <= limite) resultado.add(p);
        bajoInventarioRecursivo(indice + 1, limite, resultado);
    }

    public boolean estaVacio() { return productos.isEmpty(); }
}
