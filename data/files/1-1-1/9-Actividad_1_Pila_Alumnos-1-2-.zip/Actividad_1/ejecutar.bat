@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist build mkdir build
javac -encoding UTF-8 -d build src\modelo\*.java src\dao\*.java src\vista\*.java
if errorlevel 1 exit /b 1
java -cp build vista.AplicaAlumno
pause
