ACTIVIDAD 01 - SISTEMA DE GESTIÓN DE ALUMNOS CON COLA FIFO

Estructura del proyecto:
  Modelo/Alumno.java       Entidad y validación de atributos.
  DAO/ColaAlumno.java      Cola estática circular y operaciones DAO.
  Vista/Principal.java     Menú interactivo de consola.

Requisitos:
  JDK 8 o superior.

Compilar:
  Abra una terminal en la carpeta que contiene Modelo, DAO y Vista.
  javac -encoding UTF-8 -d out Modelo/Alumno.java DAO/ColaAlumno.java Vista/Principal.java

Ejecutar:
  java -cp out Vista.Principal

Operaciones incluidas:
  - Insertar, eliminar y consultar el frente.
  - Mostrar todos los alumnos en orden FIFO.
  - Verificar cola vacía/llena y mostrar cantidad.
  - Buscar por código sin alterar el orden original.
  - Calcular promedio general.
  - Filtrar por promedio mínimo.
  - Obtener mayor y menor promedio.
  - Invertir el orden mediante una pila auxiliar.
  - Eliminar por código manteniendo el orden de los demás.

Validaciones:
  - Capacidad mayor que cero.
  - Código y nombre no vacíos.
  - Edad de 1 a 120 años.
  - Promedio de 0 a 20.
  - Errores de cola vacía/llena controlados.
  - No permite registrar códigos duplicados desde el menú.

Diseño:
  Modelo contiene los datos del alumno; DAO contiene la lógica de la estructura
  de datos; Vista gestiona el menú y la entrada/salida. La cola se implementa
  con arreglo estático circular y respeta FIFO en sus operaciones habituales.
