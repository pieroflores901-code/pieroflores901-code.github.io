package Modelo;

public class Alumno {

    private int codigo;
    private String nombres;
    private String apellidos;
    private int edad;
    private String carrera;

    public Alumno() {
    }

    public Alumno(int codigo, String nombres, String apellidos, int edad, String carrera) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
        this.carrera = carrera;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo
                + " | Nombres: " + nombres
                + " | Apellidos: " + apellidos
                + " | Edad: " + edad
                + " | Carrera: " + carrera;
    }
}
