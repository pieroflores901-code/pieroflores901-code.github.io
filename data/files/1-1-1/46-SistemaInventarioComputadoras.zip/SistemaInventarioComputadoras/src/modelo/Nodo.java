package modelo;

/**
 * Nodo de una lista simplemente enlazada.
 */
public class Nodo {
    private final Computadora computadora;
    private Nodo siguiente;

    public Nodo(Computadora computadora) {
        if (computadora == null) throw new IllegalArgumentException("La computadora no puede ser null.");
        this.computadora = computadora;
    }

    public Computadora getComputadora() { return computadora; }
    public Nodo getSiguiente() { return siguiente; }
    public void setSiguiente(Nodo siguiente) { this.siguiente = siguiente; }
}
