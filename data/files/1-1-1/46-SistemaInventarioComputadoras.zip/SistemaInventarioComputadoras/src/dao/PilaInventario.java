package dao;

import modelo.Computadora;
import modelo.Nodo;

/**
 * Pila dinámica LIFO implementada con una lista simplemente enlazada.
 * El nodo de la cima es el último equipo ingresado.
 */
public class PilaInventario {
    private Nodo cima;
    private int cantidad;

    public boolean estaVacia() { return cima == null; }
    public int contarComputadoras() { return cantidad; }

    public void apilarComputadora(Computadora computadora) {
        Nodo nuevo = new Nodo(computadora);
        nuevo.setSiguiente(cima);
        cima = nuevo;
        cantidad++;
    }

    public Computadora consultarCima() {
        return cima == null ? null : cima.getComputadora();
    }

    public Computadora desapilarComputadora() {
        if (cima == null) return null;
        Computadora retirada = cima.getComputadora();
        cima = cima.getSiguiente();
        cantidad--;
        return retirada;
    }

    public void mostrarInventario() {
        if (estaVacia()) {
            System.out.println("El inventario está vacío.");
            return;
        }
        System.out.println("\n--- INVENTARIO (de la cima a la base) ---");
        Nodo actual = cima;
        int posicion = 1;
        while (actual != null) {
            System.out.println(posicion + ". " + actual.getComputadora());
            actual = actual.getSiguiente();
            posicion++;
        }
        System.out.println("Total de equipos: " + cantidad);
    }

    public void limpiarInventario() {
        // Se eliminan las referencias enlazadas para permitir que el GC libere los nodos.
        while (cima != null) {
            Nodo siguiente = cima.getSiguiente();
            cima.setSiguiente(null);
            cima = siguiente;
        }
        cantidad = 0;
    }

    public Computadora buscarPorSerie(String serie) {
        if (serie == null) return null;
        Nodo actual = cima;
        while (actual != null) {
            if (actual.getComputadora().getNumeroSerie().equalsIgnoreCase(serie.trim()))
                return actual.getComputadora();
            actual = actual.getSiguiente();
        }
        return null;
    }

    /** Posición relativa desde la cima; empieza en 1. */
    public int posicionPorSerie(String serie) {
        if (serie == null) return -1;
        Nodo actual = cima;
        int posicion = 1;
        while (actual != null) {
            if (actual.getComputadora().getNumeroSerie().equalsIgnoreCase(serie.trim()))
                return posicion;
            actual = actual.getSiguiente();
            posicion++;
        }
        return -1;
    }

    public double calcularValorInventario() {
        double total = 0.0;
        Nodo actual = cima;
        while (actual != null) {
            total += actual.getComputadora().getPrecio();
            actual = actual.getSiguiente();
        }
        return total;
    }

    public void mostrarEquiposSuperioresA(double precioLimite) {
        if (precioLimite < 0 || !Double.isFinite(precioLimite)) {
            System.out.println("El límite debe ser un número válido y no negativo.");
            return;
        }
        Nodo actual = cima;
        int encontrados = 0;
        while (actual != null) {
            Computadora c = actual.getComputadora();
            if (c.getPrecio() > precioLimite) {
                System.out.println(c);
                encontrados++;
            }
            actual = actual.getSiguiente();
        }
        if (encontrados == 0)
            System.out.println("No hay computadoras con precio superior a S/ " + String.format("%.2f", precioLimite));
    }

    public Computadora obtenerEquipoMasCaro() {
        if (cima == null) return null;
        Computadora masCaro = cima.getComputadora();
        Nodo actual = cima.getSiguiente();
        while (actual != null) {
            if (actual.getComputadora().getPrecio() > masCaro.getPrecio())
                masCaro = actual.getComputadora();
            actual = actual.getSiguiente();
        }
        return masCaro;
    }
}
