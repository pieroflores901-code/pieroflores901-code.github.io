# Análisis de complejidad temporal y espacial

Sea **n** el número de productos registrados.

| Operación | Tiempo | Espacio auxiliar | Explicación |
|---|---:|---:|---|
| Registrar producto | O(n) | O(1) | Comprueba códigos duplicados recorriendo la lista. |
| Mostrar productos | O(n log n) | O(n) | Ordena por código y crea una copia de la lista. |
| Búsqueda binaria recursiva | O(log n) búsqueda; O(n log n) incluyendo ordenamiento | O(log n) pila recursiva | Cada llamada reduce aproximadamente a la mitad el rango. El ordenamiento previo domina el coste total. |
| Valor total recursivo | O(n) | O(n) | Visita cada producto una vez y acumula el valor. |
| Total de unidades recursivo | O(n) | O(n) | Visita cada producto una vez. |
| Productos sin existencias | O(n) | O(k) resultado + O(n) pila | Recorre todos los productos; k es el número de resultados. |
| Reporte de bajo inventario | O(n) | O(k) resultado + O(n) pila | Recorre todos los productos; k es el número de coincidencias. |

## Observación espacial
Las funciones recursivas lineales usan hasta O(n) marcos de pila. Para inventarios muy grandes, una implementación iterativa evitaría ese coste y el riesgo de desbordamiento de pila. La búsqueda binaria recursiva usa O(log n) marcos, una vez ordenada la colección.
