Documento de prueba en formato Markdown.
