package modelo;

import java.nio.file.Path;

/** Representa un archivo o directorio encontrado durante el análisis. */
public final class ArchivoInfo {
    private final Path ruta;
    private final boolean directorio;
    private final long tamanoBytes;

    public ArchivoInfo(Path ruta, boolean directorio, long tamanoBytes) {
        if (ruta == null) {
            throw new IllegalArgumentException("La ruta no puede ser nula.");
        }
        this.ruta = ruta.toAbsolutePath().normalize();
        this.directorio = directorio;
        this.tamanoBytes = Math.max(0L, tamanoBytes);
    }

    public Path getRuta() { return ruta; }
    public String getNombre() {
        Path nombre = ruta.getFileName();
        return nombre == null ? ruta.toString() : nombre.toString();
    }
    public boolean isDirectorio() { return directorio; }
    public long getTamanoBytes() { return tamanoBytes; }

    /** Devuelve la extensión en minúsculas; usa "(sin extensión)" cuando no existe. */
    public String getExtension() {
        if (directorio) return "(directorio)";
        String nombre = getNombre();
        int punto = nombre.lastIndexOf('.');
        if (punto <= 0 || punto == nombre.length() - 1) return "(sin extensión)";
        return nombre.substring(punto + 1).toLowerCase(java.util.Locale.ROOT);
    }
}
