package Modelo;

public class Cliente {
    private String numeroTicket;
    private String dni;
    private String nombre;
    private String tipoTramite;
    private int prioridad; // 1 = Normal, 2 = Preferencial
    private String horaLlegada;

    public Cliente(String numeroTicket, String dni, String nombre,
                   String tipoTramite, int prioridad, String horaLlegada) {
        this.numeroTicket = numeroTicket;
        this.dni = dni;
        this.nombre = nombre;
        this.tipoTramite = tipoTramite;
        this.prioridad = prioridad;
        this.horaLlegada = horaLlegada;
    }

    public String getNumeroTicket() { return numeroTicket; }
    public void setNumeroTicket(String numeroTicket) { this.numeroTicket = numeroTicket; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTipoTramite() { return tipoTramite; }
    public void setTipoTramite(String tipoTramite) { this.tipoTramite = tipoTramite; }
    public int getPrioridad() { return prioridad; }
    public void setPrioridad(int prioridad) { this.prioridad = prioridad; }
    public String getHoraLlegada() { return horaLlegada; }
    public void setHoraLlegada(String horaLlegada) { this.horaLlegada = horaLlegada; }

    @Override
    public String toString() {
        return "Ticket: " + numeroTicket
                + " | DNI: " + dni
                + " | Cliente: " + nombre
                + " | Trámite: " + tipoTramite
                + " | Prioridad: " + (prioridad == 2 ? "Preferencial" : "Normal")
                + " | Hora: " + horaLlegada;
    }
}
