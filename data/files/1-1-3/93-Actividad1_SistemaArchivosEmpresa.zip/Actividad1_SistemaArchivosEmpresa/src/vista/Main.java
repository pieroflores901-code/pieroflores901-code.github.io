package vista;

import javax.swing.SwingUtilities;

/** Punto de entrada de la aplicación. */
public final class Main {
    private Main() { }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}
