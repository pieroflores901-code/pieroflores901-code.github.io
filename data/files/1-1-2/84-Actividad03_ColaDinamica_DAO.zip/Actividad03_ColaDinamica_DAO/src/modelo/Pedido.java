package modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa un pedido de cocina.
 */
public class Pedido {
    private String codigo;
    private String nombreCliente;
    private String descripcionPlatillo;
    private double montoTotal;
    private String tipoComida;
    private LocalDateTime horaRegistro;

    public Pedido(String codigo, String nombreCliente, String descripcionPlatillo,
                  double montoTotal, String tipoComida) {
        setCodigo(codigo);
        setNombreCliente(nombreCliente);
        setDescripcionPlatillo(descripcionPlatillo);
        setMontoTotal(montoTotal);
        setTipoComida(tipoComida);
        this.horaRegistro = LocalDateTime.now();
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty())
            throw new IllegalArgumentException("El código no puede estar vacío.");
        this.codigo = codigo.trim();
    }

    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) {
        if (nombreCliente == null || nombreCliente.trim().isEmpty())
            throw new IllegalArgumentException("El nombre del cliente no puede estar vacío.");
        this.nombreCliente = nombreCliente.trim();
    }

    public String getDescripcionPlatillo() { return descripcionPlatillo; }
    public void setDescripcionPlatillo(String descripcionPlatillo) {
        if (descripcionPlatillo == null || descripcionPlatillo.trim().isEmpty())
            throw new IllegalArgumentException("La descripción del platillo no puede estar vacía.");
        this.descripcionPlatillo = descripcionPlatillo.trim();
    }

    public double getMontoTotal() { return montoTotal; }
    public void setMontoTotal(double montoTotal) {
        if (montoTotal < 0 || Double.isNaN(montoTotal) || Double.isInfinite(montoTotal))
            throw new IllegalArgumentException("El monto debe ser un número válido y no negativo.");
        this.montoTotal = montoTotal;
    }

    public String getTipoComida() { return tipoComida; }
    public void setTipoComida(String tipoComida) {
        if (tipoComida == null || tipoComida.trim().isEmpty())
            throw new IllegalArgumentException("El tipo de comida no puede estar vacío.");
        this.tipoComida = tipoComida.trim();
    }

    public LocalDateTime getHoraRegistro() { return horaRegistro; }

    @Override
    public String toString() {
        return "Código: " + codigo
                + " | Cliente: " + nombreCliente
                + " | Platillo: " + descripcionPlatillo
                + " | Tipo: " + tipoComida
                + " | Total: S/ " + String.format("%.2f", montoTotal)
                + " | Registrado: " + horaRegistro.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }
}
