package servicio;

import dao.ArchivoDAO;
import modelo.ArchivoInfo;
import modelo.ResultadoAnalisis;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Contiene la lógica de negocio y los algoritmos recursivos del proyecto. */
public class AnalizadorArchivos {
    private final ArchivoDAO dao;

    public AnalizadorArchivos(ArchivoDAO dao) {
        if (dao == null) throw new IllegalArgumentException("El DAO es obligatorio.");
        this.dao = dao;
    }

    public ResultadoAnalisis analizar(Path raiz) throws IOException {
        if (raiz == null || !Files.isDirectory(raiz, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("Selecciona una carpeta válida.");
        }
        List<ArchivoInfo> elementos = new ArrayList<ArchivoInfo>();
        List<String> advertencias = new ArrayList<String>();
        recorrerDirectorio(raiz.toAbsolutePath().normalize(), elementos, advertencias);
        return new ResultadoAnalisis(raiz, elementos, advertencias);
    }

    /** Caso base: no hay hijos que procesar. Caso recursivo: procesa cada hijo. */
    private void recorrerDirectorio(Path directorio, List<ArchivoInfo> salida,
                                    List<String> advertencias) {
        List<Path> hijos;
        try {
            hijos = dao.listarHijos(directorio);
        } catch (IOException ex) {
            advertencias.add("No se pudo leer " + directorio + ": " + ex.getMessage());
            return;
        }
        for (Path hijo : hijos) {
            if (dao.esDirectorio(hijo)) {
                salida.add(new ArchivoInfo(hijo, true, 0));
                recorrerDirectorio(hijo, salida, advertencias);
            } else if (dao.esArchivoRegular(hijo)) {
                try {
                    salida.add(new ArchivoInfo(hijo, false, dao.obtenerTamano(hijo)));
                } catch (IOException | SecurityException ex) {
                    advertencias.add("No se pudo leer el tamaño de " + hijo);
                    salida.add(new ArchivoInfo(hijo, false, 0));
                }
            }
        }
    }

    /** Búsqueda recursiva por nombre completo o fragmento, sin distinguir mayúsculas. */
    public List<ArchivoInfo> buscarPorNombre(ResultadoAnalisis resultado, String consulta) {
        if (resultado == null) return Collections.emptyList();
        String q = consulta == null ? "" : consulta.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return Collections.emptyList();
        List<ArchivoInfo> encontrados = new ArrayList<ArchivoInfo>();
        buscarNombreRec(resultado.getElementos(), 0, q, encontrados);
        return Collections.unmodifiableList(encontrados);
    }

    private void buscarNombreRec(List<ArchivoInfo> lista, int indice, String q,
                                 List<ArchivoInfo> encontrados) {
        if (indice >= lista.size()) return; // caso base
        ArchivoInfo actual = lista.get(indice);
        if (!actual.isDirectorio() && actual.getNombre().toLowerCase(Locale.ROOT).contains(q)) {
            encontrados.add(actual);
        }
        buscarNombreRec(lista, indice + 1, q, encontrados); // caso recursivo
    }

    /** Busca por extensión; acepta "pdf" o ".pdf". */
    public List<ArchivoInfo> buscarPorExtension(ResultadoAnalisis resultado, String extension) {
        if (resultado == null) return Collections.emptyList();
        String q = extension == null ? "" : extension.trim().toLowerCase(Locale.ROOT);
        if (q.startsWith(".")) q = q.substring(1);
        if (q.isEmpty()) return Collections.emptyList();
        List<ArchivoInfo> encontrados = new ArrayList<ArchivoInfo>();
        buscarExtensionRec(resultado.getElementos(), 0, q, encontrados);
        return Collections.unmodifiableList(encontrados);
    }

    private void buscarExtensionRec(List<ArchivoInfo> lista, int indice, String q,
                                    List<ArchivoInfo> encontrados) {
        if (indice >= lista.size()) return;
        ArchivoInfo actual = lista.get(indice);
        if (!actual.isDirectorio() && actual.getExtension().equals(q)) encontrados.add(actual);
        buscarExtensionRec(lista, indice + 1, q, encontrados);
    }

    /** Genera una representación jerárquica recursiva desde la raíz elegida. */
    public String mostrarEstructura(ResultadoAnalisis resultado) {
        if (resultado == null) return "Primero analiza una carpeta.";
        StringBuilder sb = new StringBuilder();
        sb.append(resultado.getRaiz().getFileName() == null
                ? resultado.getRaiz() : resultado.getRaiz().getFileName()).append('\n');
        List<Path> hijos;
        try {
            hijos = dao.listarHijos(resultado.getRaiz());
        } catch (IOException ex) {
            return sb.append("  [No se pudo leer la carpeta: ").append(ex.getMessage()).append("]\n").toString();
        }
        for (int i = 0; i < hijos.size(); i++) {
            mostrarNodo(hijos.get(i), "", i == hijos.size() - 1, sb);
        }
        return sb.toString();
    }

    private void mostrarNodo(Path ruta, String prefijo, boolean ultimo, StringBuilder sb) {
        boolean directorio = dao.esDirectorio(ruta);
        sb.append(prefijo).append(ultimo ? "└── " : "├── ")
          .append(ruta.getFileName()).append(directorio ? "/" : "").append('\n');
        if (!directorio) return;
        List<Path> hijos;
        try {
            hijos = dao.listarHijos(ruta);
        } catch (IOException ex) {
            sb.append(prefijo).append(ultimo ? "    " : "│   ")
              .append("[No se pudo acceder]\n");
            return;
        }
        String nuevoPrefijo = prefijo + (ultimo ? "    " : "│   ");
        for (int i = 0; i < hijos.size(); i++) {
            mostrarNodo(hijos.get(i), nuevoPrefijo, i == hijos.size() - 1, sb);
        }
    }
}
