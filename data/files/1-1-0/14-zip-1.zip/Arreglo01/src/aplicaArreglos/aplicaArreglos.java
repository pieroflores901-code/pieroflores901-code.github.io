package aplicaArreglos;

import arreglo01.Arreglo01;
import java.util.Scanner;

public class aplicaArreglos {

    static Arreglo01 objArreglo = new Arreglo01();
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        int opcion, tam, x, nuevo, y;

        do {
            System.out.println("     Menu de Opciones");
            System.out.println("-------------------------");
            System.out.println("1.- Crear Arreglo");
            System.out.println("2.- Ingresar Datos");
            System.out.println("3.- Mostrar Datos");
            System.out.println("4.- Eliminar Elemento");
            System.out.println("5.- Modificar Elemento");
            System.out.println("6.- Insertar Elemento");
            System.out.println("7.- Sumar Elementos");
            System.out.println("8.- Menor, Mayor y Promedio");
            System.out.println("9.- Sumar Impares");
            System.out.println("10.- Primer Elemento al Final");
            System.out.println("11.- Primer Par al Final");
            System.out.println("0.- Salir");
            System.out.println("-------------------------");
            System.out.print("Ingrese una alternativa: ");
            opcion = teclado.nextInt();
            System.out.println();

            if (opcion == 1) {
                System.out.print("Ingrese tamano del Arreglo : ");
                tam = teclado.nextInt();
                objArreglo.creaArreglo(tam);
            }

            if (opcion == 2) {
                objArreglo.lectura();
            }

            if (opcion == 3) {
                objArreglo.escritura();
            }

            if (opcion == 4) {
                System.out.print("Ingrese elemento a eliminar : ");
                x = teclado.nextInt();
                objArreglo.eliminarElemento(x);
            }

            if (opcion == 5) {
                System.out.print("Ingrese elemento a modificar : ");
                x = teclado.nextInt();
                System.out.print("Ingrese nuevo elemento : ");
                nuevo = teclado.nextInt();
                objArreglo.modificarElemento(x, nuevo);
            }

            if (opcion == 6) {
                System.out.print("Ingrese elemento a insertar : ");
                x = teclado.nextInt();
                System.out.print("Ingrese posicion : ");
                y = teclado.nextInt();
                objArreglo.insertarElemento(x, y);
            }

            if (opcion == 7) {
                objArreglo.sumarElementos();
            }

            if (opcion == 8) {
                objArreglo.menorMayorPromedio();
            }

            if (opcion == 9) {
                objArreglo.sumarImpares();
            }

            if (opcion == 10) {
                objArreglo.primerElementoAlFinal();
            }

            if (opcion == 11) {
                objArreglo.primerParAlFinal();
            }

        } while (opcion != 0);
    }
}
